#![deny(warnings)]
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")] // hide console on Windows
#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;

mod cheats;
mod device;
mod netplay;
mod savestates;
mod ui;

use clap::Parser;
use ui::gui;

/// --------------------------- CLI ---------------------------

#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// Path to a ROM file; if omitted the GUI launcher opens
    game: Option<String>,

    #[arg(short, long)]
    fullscreen: bool,

    /// Create a new input profile
    #[arg(short, long, value_name = "PROFILE")]
    configure_input_profile: Option<String>,

    /// Use DirectInput when creating a new profile
    #[arg(short, long)]
    use_dinput: bool,

    /// Bind an existing profile to --port
    #[arg(short, long, value_name = "PROFILE")]
    bind_input_profile: Option<String>,

    /// List connected controllers
    #[arg(short, long)]
    list_controllers: bool,

    /// Assign a controller (index from --list‑controllers) to --port
    #[arg(short, long, value_name = "NUMBER")]
    assign_controller: Option<i32>,

    /// Port number 1‑4 (used with --bind‑input‑profile / --assign‑controller)
    #[arg(short, long, value_name = "PORT")]
    port: Option<usize>,

    /// Clear *all* input bindings
    #[arg(short = 'z', long)]
    clear_input_bindings: bool,

    /// Launch the input configuration wizard (GUI)
#[arg(long)]
input_wizard: bool,

}

/// --------------------------- entry point ---------------------------

#[tokio::main]
async fn main() {
    // 1️⃣  start SDL’s VIDEO & GAMEPAD subsystems on the **main thread**
    ui::sdl_init(
        sdl3_sys::init::SDL_INIT_VIDEO | sdl3_sys::init::SDL_INIT_GAMEPAD,
    );

    // 2️⃣  make sure config / data folders exist
    let dirs = ui::get_dirs();
    std::fs::create_dir_all(&dirs.config_dir).expect("cannot create config dir");
    std::fs::create_dir_all(dirs.data_dir.join("saves")).expect("cannot create saves dir");
    std::fs::create_dir_all(dirs.data_dir.join("states")).expect("cannot create states dir");

    // 3️⃣  parse CLI
    let args = Args::parse();

    // -----------------------------------------------------------------
    //   “utility mode” – we passed flags but no ROM path
    // -----------------------------------------------------------------
    if std::env::args().len() > 1 && args.game.is_none() {
        let mut ui = ui::Ui::new();

        if args.input_wizard {
            // Default profile name for wizard
            let profile = "custom".to_string();
            ui::input::configure_input_profile(&mut ui, profile, args.use_dinput);
            return;
        }
    

        if args.clear_input_bindings {
            ui::input::clear_bindings(&mut ui);
            return;
        }

        if let Some(port) = args.port {
            if !(1..=4).contains(&port) {
                eprintln!("Port must be between 1 and 4");
                return;
            }
        }

        if args.list_controllers {
            for (i, name) in ui::input::get_controller_names(&ui).iter().enumerate() {
                println!("Controller {i}: {name}");
            }
            return;
        }

        if let Some(profile) = args.configure_input_profile {
            ui::input::configure_input_profile(&mut ui, profile, args.use_dinput);
            return;
        }

        if let Some(index) = args.assign_controller {
            let port = args.port.expect("must specify --port with --assign‑controller");
            ui::input::assign_controller(&mut ui, index, port);
            return;
        }

        if let Some(profile) = args.bind_input_profile {
            let port = args.port.expect("must specify --port with --bind‑input‑profile");
            ui::input::bind_input_profile(&mut ui, profile, port);
            return;
        }

        // no matching utility flag – fall through to GUI
    }

    // -----------------------------------------------------------------
    //   “emulation mode” – a ROM path was supplied
    // -----------------------------------------------------------------
    if let Some(rom_path) = args.game {
        let path = std::path::Path::new(&rom_path);
        let rom = match device::get_rom_contents(path) {
            Some(buf) => buf,
            None => {
                eprintln!("Could not read ROM file: {rom_path}");
                return;
            }
        };

        // everything below runs **on the main thread** (no extra spawn)
        let mut device = device::Device::new();
        let overclock             = device.ui.config.emulation.overclock;
        let disable_expansion_pak = device.ui.config.emulation.disable_expansion_pak;

        let game_cheats = {
            let crc    = ui::storage::get_game_crc(&rom);
            let cheats = ui::config::Cheats::new();
            cheats.cheats.get(&crc).cloned().unwrap_or_default()
        };

        device::run_game(
            &mut device,
            rom,
            gui::GameSettings {
                fullscreen: args.fullscreen,
                overclock,
                disable_expansion_pak,
                cheats: game_cheats,
            },
        );
    } else {
        // -----------------------------------------------------------------
        //   no ROM given, no utility flags – open the GUI launcher
        // -----------------------------------------------------------------
        gui::app_window();
    }
}
