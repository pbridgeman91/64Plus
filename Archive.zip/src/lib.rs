#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;

mod cheats;
mod device;
mod netplay;
mod savestates;
mod ui;
pub mod file_picker;

use std::ffi::CStr;
use std::os::raw::c_char;
use ui::gui;

// Global pointer to emulator device
pub static mut DEVICE_PTR: *mut device::Device = std::ptr::null_mut();
use ui::gui::NetplayDevice;



// Declare SDL_SetMainReady manually
unsafe extern "C" {
    fn SDL_SetMainReady();
}

/// --------------------------- iOS entry point ---------------------------

/// Starts the emulator with a provided ROM path, or launches the GUI if `rom_path_ptr` is NULL.
/// This is what Xcode will call via `n64Plus_start([romPath UTF8String])`.
#[unsafe(no_mangle)]
pub extern "C" fn n64Plus_start(rom_path_ptr: *const c_char) {
    // iOS-specific: SDL requires this when not using SDL_main
    unsafe { SDL_SetMainReady(); }

    // 1️⃣  Initialize SDL
    ui::sdl_init(
        sdl3_sys::init::SDL_INIT_VIDEO | sdl3_sys::init::SDL_INIT_GAMEPAD,
    );

    // 2️⃣  Ensure config and data directories
    let dirs = ui::get_dirs();
    std::fs::create_dir_all(&dirs.config_dir).expect("cannot create config dir");
    std::fs::create_dir_all(dirs.data_dir.join("saves")).expect("cannot create saves dir");
    std::fs::create_dir_all(dirs.data_dir.join("states")).expect("cannot create states dir");

    // 3️⃣  Determine ROM path (if provided)
    let rom_path = if !rom_path_ptr.is_null() {
        unsafe {
            CStr::from_ptr(rom_path_ptr)
                .to_str()
                .map(std::path::PathBuf::from)
                .ok()
        }
    } else {
        None
    };

    // 4️⃣  Run game or GUI
    if let Some(rom_path) = rom_path {
        if let Some(rom) = device::get_rom_contents(&rom_path) {
            let mut device = device::Device::new();

                    // 🔴 NEW: publish the pointer so FFI can find the live device
        unsafe { DEVICE_PTR = &mut device as *mut device::Device; }

                    // ✅ Quick-resume: if a savestate exists for this ROM/hash, load it now
                    //depreciated.....calling here ends up being too early.....
                    //leaving for future use for real savestates
    //   {
    //       use crate::savestates::{savestate_path_for, load_savestate};
    //       let path = savestate_path_for(&device);
    //       if path.exists() {
    //           eprintln!("🟢 [Savestate] Autoload at boot → {}", path.display());
    //           load_savestate(&mut device);
    //       } else {
    //           eprintln!("🟡 [Savestate] No state at boot (expected at {})", path.display());
    //       }
    //   }

            let overclock = device.ui.config.emulation.overclock;
            let disable_expansion_pak = device.ui.config.emulation.disable_expansion_pak;

            let game_cheats = {
                let crc = ui::storage::get_game_crc(&rom);
                let cheats = ui::config::Cheats::new();
                cheats.cheats.get(&crc).cloned().unwrap_or_default()
            };

            device::run_game(
                &mut device,
                rom,
                gui::GameSettings {
                    fullscreen: true,
                    overclock,
                    disable_expansion_pak,
                    cheats: game_cheats,
                },
            );
                    // 👇 clear it when the game loop exits
        unsafe { DEVICE_PTR = std::ptr::null_mut(); }
            return;
        } else {
            eprintln!("Could not read ROM: {:?}", rom_path);
        }
    }

    // If no ROM or failed load, show GUI
    gui::app_window();


}



////////
use std::net::ToSocketAddrs;
#[unsafe(no_mangle)]
pub unsafe extern "C" fn n64Plus_start_netplay(
    rom_path_ptr: *const c_char,
    host_port_ptr: *const c_char,
    player_number: u8,
    disable_pak: bool,
    fullscreen: bool,
    overclock: bool,
) {
    // ---- 0. Parse C strings ----
    let rom_path = {
        let s = CStr::from_ptr(rom_path_ptr)
            .to_str()
            .expect("❌ bad ROM path");
        println!("📂 ROM path received: {}", s);
        std::path::PathBuf::from(s)
    };

    let host_port_raw = CStr::from_ptr(host_port_ptr)
        .to_str()
        .expect("❌ bad peer addr");
    println!("🌐 Raw host_port string: {}", host_port_raw);

    // ---- 1. SDL init ----
    println!("🕹 Initializing SDL...");
    ui::sdl_init(
        sdl3_sys::init::SDL_INIT_VIDEO | sdl3_sys::init::SDL_INIT_GAMEPAD,
    );

    // ---- 2. Device allocation ----
//    println!("🎮 Creating new Device...");
  //  let boxed = Box::new(device::Device::new());
    //let dev_ptr = Box::into_raw(boxed);
    //DEVICE_PTR = dev_ptr;
    //let dev = &mut *dev_ptr;

    // ---- 3. Game settings ----
    println!(
        "⚙️  Settings: fullscreen={}, overclock={}, disablePak={}",
        fullscreen, overclock, disable_pak
    );
    let mut settings = gui::GameSettings {
        fullscreen,
        overclock,
        disable_expansion_pak: disable_pak,
        cheats: std::collections::HashMap::new(),
    };

    if let Some(rom) = device::get_rom_contents(&rom_path) {
        let crc = ui::storage::get_game_crc(&rom);
        let cheats = ui::config::Cheats::new();
        settings.cheats = cheats.cheats.get(&crc).cloned().unwrap_or_default();
     //   println!("✅ ROM loaded, CRC = {:X}", crc);
    } else {
        println!("❌ Failed to read ROM contents");
    }

    // ---- 4. Parse and sanitize host:port ----
    let mut cleaned = host_port_raw
        .trim_start_matches("ws://")
        .trim_start_matches("wss://")
        .to_string();

    if let Some(pos) = cleaned.find(['/', '?']) {
        cleaned.truncate(pos);
    }

    if cleaned.matches(':').count() > 1 {
        if let Some((host, port)) = cleaned.rsplit_once(':') {
            println!("🧼 Cleaning double-colon host → host={}, port={}", host, port);
            cleaned = format!("{host}:{port}");
        }
    }

    println!("🔌 Parsing socket address from: {}", cleaned);

    let socket_addr: std::net::SocketAddr = cleaned
        .parse()
        .unwrap_or_else(|_| {
            // `parse()` failed (likely hostname). Do a DNS lookup instead.
            println!("🌐 Hostname detected, resolving…");
            match cleaned.to_socket_addrs()
                         .ok()
                         .and_then(|mut iter| iter.next())
            {
                Some(addr) => {
                    println!("✅ Resolved to {}", addr);
                    addr
                }
                None => panic!("❌ peer must resolve to a socket address"),
            }
        });
    

    println!("✅ Parsed socket addr: {}", socket_addr);

    let net_dev = NetplayDevice {
        peer_addr: socket_addr,
        player_number,
    };

    // ---- 5. Launch ROM ----
    println!("🚀 Calling run_rom() with netplay enabled");
    let vru = ui::gui::VruChannel::default();
    let weak = slint::Weak::<ui::gui::AppWindow>::default();

    ui::gui::run_rom(
        ui::gui::GbPaths::default(),
        rom_path,
        settings,
        vru,
        Some(net_dev),
        weak,
    );
}


//ios audio
use crate::ui::audio; // <-- add this import
#[unsafe(no_mangle)]
pub extern "C" fn engine_set_initial_gain(g: f32) {
    let g = if g.is_finite() { g.clamp(0.0, 2.0) } else { 1.0 };
    audio::audio_set_gain(g); // <-- call via ui::audio
}


#[unsafe(no_mangle)]
pub extern "C" fn n64Plus_any_save_dirty() -> bool {
    unsafe {
        if DEVICE_PTR.is_null() { return false; }
        let dev = &*DEVICE_PTR;
        let s = &dev.ui.storage.saves;
        s.eeprom.written
            || s.sram.written
            || s.flash.written
            || s.mempak.written
            || s.sdcard.written
            || s.romsave.written
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn n64Plus_flush_saves_now() {
    unsafe {
        if DEVICE_PTR.is_null() { return; }
        let dev = &mut *DEVICE_PTR;

        // Persist to disk (host-only in netplay, as your write_saves already does)
        ui::storage::write_saves(dev);

        // IMPORTANT: clear dirty flags so we don’t keep re-flushing
        let s = &mut dev.ui.storage.saves;
        s.eeprom.written  = false;
        s.sram.written    = false;
        s.flash.written   = false;
        s.mempak.written  = false;
        s.sdcard.written  = false;
        s.romsave.written = false;
    }
}


// lib.rs

// ... (keep all your existing code) ...

#[unsafe(no_mangle)]
pub extern "C" fn n64Plus_create_savestate() {
    unsafe {
        if DEVICE_PTR.is_null() {
            eprintln!("Savestate creation failed: No active device.");
            return;
        }
        let dev = &*DEVICE_PTR;
        println!("Creating savestate...");
        crate::savestates::create_savestate(dev);
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn n64Plus_load_savestate() {
    unsafe {
        if DEVICE_PTR.is_null() {
            eprintln!("Savestate load failed: No active device.");
            return;
        }
        let dev = &mut *DEVICE_PTR;
        println!("Loading savestate...");
        crate::savestates::load_savestate(dev);
    }
}
