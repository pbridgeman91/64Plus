#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;

mod cheats;
mod device;
mod netplay;
mod savestates;
mod ui;
pub mod file_picker;

use std::ffi::CStr;
use std::os::raw::c_char;
use ui::gui;

// Declare SDL_SetMainReady manually
unsafe extern "C" {
    fn SDL_SetMainReady();
}

/// --------------------------- iOS entry point ---------------------------

/// Starts the emulator with a provided ROM path, or launches the GUI if `rom_path_ptr` is NULL.
/// This is what Xcode will call via `n64Plus_start([romPath UTF8String])`.
#[unsafe(no_mangle)]
pub extern "C" fn n64Plus_start(rom_path_ptr: *const c_char) {
    // iOS-specific: SDL requires this when not using SDL_main
    unsafe { SDL_SetMainReady(); }

    // 1️⃣  Initialize SDL
    ui::sdl_init(
        sdl3_sys::init::SDL_INIT_VIDEO | sdl3_sys::init::SDL_INIT_GAMEPAD,
    );

    // 2️⃣  Ensure config and data directories
    let dirs = ui::get_dirs();
    std::fs::create_dir_all(&dirs.config_dir).expect("cannot create config dir");
    std::fs::create_dir_all(dirs.data_dir.join("saves")).expect("cannot create saves dir");
    std::fs::create_dir_all(dirs.data_dir.join("states")).expect("cannot create states dir");

    // 3️⃣  Determine ROM path (if provided)
    let rom_path = if !rom_path_ptr.is_null() {
        unsafe {
            CStr::from_ptr(rom_path_ptr)
                .to_str()
                .map(std::path::PathBuf::from)
                .ok()
        }
    } else {
        None
    };

    // 4️⃣  Run game or GUI
    if let Some(rom_path) = rom_path {
        if let Some(rom) = device::get_rom_contents(&rom_path) {
            let mut device = device::Device::new();
            let overclock = device.ui.config.emulation.overclock;
            let disable_expansion_pak = device.ui.config.emulation.disable_expansion_pak;

            let game_cheats = {
                let crc = ui::storage::get_game_crc(&rom);
                let cheats = ui::config::Cheats::new();
                cheats.cheats.get(&crc).cloned().unwrap_or_default()
            };

            device::run_game(
                &mut device,
                rom,
                gui::GameSettings {
                    fullscreen: false,
                    overclock,
                    disable_expansion_pak,
                    cheats: game_cheats,
                },
            );
            return;
        } else {
            eprintln!("Could not read ROM: {:?}", rom_path);
        }
    }

    // If no ROM or failed load, show GUI
    gui::app_window();


}
