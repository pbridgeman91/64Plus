use crate::device;
use crate::netplay;
use crate::ui;

pub struct EventAudio {
    pub mempak: Vec<u8>,
    pub rumblepak: Vec<u8>,
    pub transferpak: Vec<u8>,
    pub netplay_desync: Vec<u8>,
    pub netplay_lost_connection: Vec<u8>,
    pub netplay_disconnected: [Vec<u8>; 4],
    pub cheats_enabled: Vec<u8>,
}

use std::sync::atomic::{AtomicPtr, AtomicU32, Ordering};
use std::ffi::c_void;
use std::ffi::CString;


static AUDIO_STREAM_PTR: AtomicPtr<c_void> = AtomicPtr::new(std::ptr::null_mut());
static EVENT_STREAM_PTR: AtomicPtr<c_void> = AtomicPtr::new(std::ptr::null_mut());

// store gain bits to avoid non-atomic f32; default 1.0
static GAIN_BITS: AtomicU32 = AtomicU32::new(1.0_f32.to_bits());



#[cfg(target_os = "ios")]
mod ios_hooks {
    use std::ffi::{c_void, CString};
    use std::sync::Once;
    use libc::{dlsym, RTLD_DEFAULT};

    static INIT: Once = Once::new();
    static mut ENFORCE: Option<unsafe extern "C" fn()> = None;
    static mut RELINQUISH: Option<unsafe extern "C" fn()> = None;
    static mut EXTERNAL_PRIMARY: Option<unsafe extern "C" fn() -> bool> = None;

    pub unsafe fn enforce_non_ducking() {
        INIT.call_once(resolve);
        if let Some(f) = ENFORCE { f(); }
    }
    pub unsafe fn relinquish() {
        INIT.call_once(resolve);
        if let Some(f) = RELINQUISH { f(); }
    }
    pub unsafe fn external_audio_primary() -> bool {
        INIT.call_once(resolve);
        if let Some(f) = EXTERNAL_PRIMARY { return f(); }
        false
    }

    fn resolve() { unsafe {
        ENFORCE          = sym0("ios_enforce_non_ducking");
        RELINQUISH       = sym0("ios_audio_relinquish");
        EXTERNAL_PRIMARY = sym1("ios_external_audio_primary");
    }}

    // resolve void() symbol
    unsafe fn sym0(name: &str) -> Option<unsafe extern "C" fn()> {
        let c = CString::new(name).unwrap();
        let p = dlsym(RTLD_DEFAULT, c.as_ptr());
        if p.is_null() { None } else {
            Some(std::mem::transmute::<*mut c_void, unsafe extern "C" fn()>(p))
        }
    }

    // resolve bool() symbol
    unsafe fn sym1(name: &str) -> Option<unsafe extern "C" fn() -> bool> {
        let c = CString::new(name).unwrap();
        let p = dlsym(RTLD_DEFAULT, c.as_ptr());
        if p.is_null() { None } else {
            Some(std::mem::transmute::<*mut c_void, unsafe extern "C" fn() -> bool>(p))
        }
    }
}




///ios
#[unsafe(no_mangle)]
pub extern "C" fn audio_set_gain(gain: f32) {
    set_both_streams_gain(gain);
}

#[unsafe(no_mangle)]
pub extern "C" fn audio_get_gain() -> f32 {
    f32::from_bits(GAIN_BITS.load(Ordering::SeqCst))
}

#[unsafe(no_mangle)]
pub extern "C" fn audio_increase_gain(step: f32) {
    let cur = f32::from_bits(GAIN_BITS.load(Ordering::SeqCst));
    set_both_streams_gain(cur + if step.is_finite() && step > 0.0 { step } else { 0.05 });
}

#[unsafe(no_mangle)]
pub extern "C" fn audio_decrease_gain(step: f32) {
    let cur = f32::from_bits(GAIN_BITS.load(Ordering::SeqCst));
    set_both_streams_gain(cur - if step.is_finite() && step > 0.0 { step } else { 0.05 });
}

#[unsafe(no_mangle)]
pub extern "C" fn audio_mute() {
    set_both_streams_gain(0.0);
}

#[unsafe(no_mangle)]
pub extern "C" fn audio_unmute_to_default() {
    set_both_streams_gain(1.0);
}






#[inline]
fn clamp_gain(v: f32) -> f32 {
    if v < 0.0 { 0.0 } else if v > 2.0 { 2.0 } else { v }
}

fn set_both_streams_gain(g: f32) {
    let g = clamp_gain(g);
    let a = AUDIO_STREAM_PTR.load(Ordering::SeqCst) as *mut sdl3_sys::audio::SDL_AudioStream;
    let e = EVENT_STREAM_PTR.load(Ordering::SeqCst) as *mut sdl3_sys::audio::SDL_AudioStream;
    unsafe {
        if !a.is_null() { sdl3_sys::audio::SDL_SetAudioStreamGain(a, g); }
        if !e.is_null() { sdl3_sys::audio::SDL_SetAudioStreamGain(e, g); }
    }
    GAIN_BITS.store(g.to_bits(), Ordering::SeqCst);
}


pub fn init(ui: &mut ui::Ui, frequency: u64) {
    ui::sdl_init(sdl3_sys::init::SDL_INIT_AUDIO);

     // iOS: force ambient/no-duck, and bail out if external audio is primary
#[cfg(target_os = "ios")]
unsafe fn set_ios_audio_hints() {
    use std::ffi::CString;

    // Correct key (SDL3): do NOT use SDL_AUDIO_IOS_CATEGORY
    sdl3_sys::everything::SDL_SetHint(
        CString::new("SDL_AUDIO_CATEGORY").unwrap().as_ptr(),
        CString::new("ambient").unwrap().as_ptr(),
    );

    // If your SDL3 has this, it will disable ducking; if not, it’s a harmless no-op.
    sdl3_sys::everything::SDL_SetHint(
        CString::new("SDL_AUDIO_DUCKING").unwrap().as_ptr(),
        CString::new("0").unwrap().as_ptr(),
    );

    // Optional: also set the old SDL2 key as a belt-and-suspenders; unknown keys are ignored.
    sdl3_sys::everything::SDL_SetHint(
        CString::new("SDL_IOS_AUDIO_CATEGORY").unwrap().as_ptr(),
        CString::new("ambient").unwrap().as_ptr(),
    );
}



    let device_audio_spec = sdl3_sys::audio::SDL_AudioSpec {
        format: sdl3_sys::audio::SDL_AUDIO_S16LE,
        freq: 48000,
        channels: 2,
    };
    ui.audio.audio_device = unsafe {
        sdl3_sys::audio::SDL_OpenAudioDevice(
            sdl3_sys::audio::SDL_AUDIO_DEVICE_DEFAULT_PLAYBACK,
            &device_audio_spec,
        )
    };
    if ui.audio.audio_device == 0 {
        panic!("Could not open audio device");
    }
#[cfg(target_os = "ios")]
unsafe { ios_hooks::enforce_non_ducking(); }

    if !unsafe {
        sdl3_sys::audio::SDL_GetAudioDeviceFormat(
            ui.audio.audio_device,
            &mut ui.audio.audio_device_spec,
            std::ptr::null_mut(),
        )
    } {
        panic!("Could not get audio device format");
    }

    let wav_audio_spec = sdl3_sys::audio::SDL_AudioSpec {
        format: sdl3_sys::audio::SDL_AUDIO_S16LE,
        freq: 24000,
        channels: 1,
    };

    ui.audio.event_audio_stream = unsafe {
        sdl3_sys::audio::SDL_CreateAudioStream(&wav_audio_spec, &ui.audio.audio_device_spec)
    };
let cached = f32::from_bits(GAIN_BITS.load(Ordering::SeqCst));
if !unsafe {
    sdl3_sys::audio::SDL_SetAudioStreamGain(ui.audio.event_audio_stream, cached)
        && sdl3_sys::audio::SDL_BindAudioStream(
            ui.audio.audio_device,
            ui.audio.event_audio_stream,
        )
} { panic!("Could not bind audio stream"); }

// cache pointer; sync Ui to cached (do NOT overwrite cache here)
EVENT_STREAM_PTR.store(ui.audio.event_audio_stream.cast(), Ordering::SeqCst);
ui.audio.gain = cached;

#[cfg(target_os = "ios")]
unsafe { ios_hooks::enforce_non_ducking(); }

    init_game_audio(ui, frequency);
    
}

pub fn init_game_audio(ui: &mut ui::Ui, frequency: u64) {
    let game_audio_spec = sdl3_sys::audio::SDL_AudioSpec {
        format: sdl3_sys::audio::SDL_AUDIO_S16LE,
        freq: frequency as i32,
        channels: 2,
    };

    ui.audio.audio_stream = unsafe {
        sdl3_sys::audio::SDL_CreateAudioStream(&game_audio_spec, &ui.audio.audio_device_spec)
    };
    if ui.audio.audio_stream.is_null() {
        return;
    }
let cached = f32::from_bits(GAIN_BITS.load(Ordering::SeqCst));
if !unsafe {
    sdl3_sys::audio::SDL_SetAudioStreamGain(ui.audio.audio_stream, cached)
        && sdl3_sys::audio::SDL_BindAudioStream(ui.audio.audio_device, ui.audio.audio_stream)
} { panic!("Could not bind audio stream"); }

// cache pointer; sync Ui to cached (do NOT overwrite cache here)
AUDIO_STREAM_PTR.store(ui.audio.audio_stream.cast(), Ordering::SeqCst);
ui.audio.gain = cached;

#[cfg(target_os = "ios")]
unsafe { ios_hooks::enforce_non_ducking(); }


}

pub fn close(ui: &mut ui::Ui) {
    close_game_audio(ui);
    unsafe {
        if !ui.audio.event_audio_stream.is_null() {
            sdl3_sys::audio::SDL_DestroyAudioStream(ui.audio.event_audio_stream);
            ui.audio.event_audio_stream = std::ptr::null_mut();
        }
        sdl3_sys::audio::SDL_CloseAudioDevice(ui.audio.audio_device);
        ui.audio.audio_device = 0;
        EVENT_STREAM_PTR.store(std::ptr::null_mut(), Ordering::SeqCst);
#[cfg(target_os = "ios")]
unsafe { ios_hooks::relinquish(); }

    }
}

pub fn close_game_audio(ui: &mut ui::Ui) {
    unsafe {
        if !ui.audio.audio_stream.is_null() {
            sdl3_sys::audio::SDL_DestroyAudioStream(ui.audio.audio_stream);
            ui.audio.audio_stream = std::ptr::null_mut();
        }
        AUDIO_STREAM_PTR.store(std::ptr::null_mut(), Ordering::SeqCst);

    }
}

pub fn lower_audio_volume(ui: &mut ui::Ui) {
    unsafe {
        ui.audio.gain = sdl3_sys::audio::SDL_GetAudioStreamGain(ui.audio.audio_stream) - 0.05;
        if ui.audio.gain < 0.0 { ui.audio.gain = 0.0; }
        sdl3_sys::audio::SDL_SetAudioStreamGain(ui.audio.audio_stream, ui.audio.gain);
        sdl3_sys::audio::SDL_SetAudioStreamGain(ui.audio.event_audio_stream, ui.audio.gain);
    }
    GAIN_BITS.store(ui.audio.gain.to_bits(), Ordering::SeqCst); // <-- add this
}

pub fn raise_audio_volume(ui: &mut ui::Ui) {
    unsafe {
        ui.audio.gain = sdl3_sys::audio::SDL_GetAudioStreamGain(ui.audio.audio_stream) + 0.05;
        if ui.audio.gain > 2.0 { ui.audio.gain = 2.0; }
        sdl3_sys::audio::SDL_SetAudioStreamGain(ui.audio.audio_stream, ui.audio.gain);
        sdl3_sys::audio::SDL_SetAudioStreamGain(ui.audio.event_audio_stream, ui.audio.gain);
    }
    GAIN_BITS.store(ui.audio.gain.to_bits(), Ordering::SeqCst); // <-- add this
}


pub fn play_cheat_event(ui: &ui::Ui) {
    if ui.audio.event_audio_stream.is_null() {
        return;
    }
    let sound = &ui.audio.event_audio.cheats_enabled;
    if !unsafe {
        sdl3_sys::audio::SDL_PutAudioStreamData(
            ui.audio.event_audio_stream,
            sound.as_ptr() as *const std::ffi::c_void,
            sound.len() as i32,
        )
    } {
        panic!("Could not play audio");
    }
}

pub fn play_netplay_audio(ui: &ui::Ui, error: u32) {
    if ui.audio.event_audio_stream.is_null() {
        return;
    }
    let sound = match error {
        netplay::NETPLAY_ERROR_DESYNC => &ui.audio.event_audio.netplay_desync,
        netplay::NETPLAY_ERROR_LOST_CONNECTION => &ui.audio.event_audio.netplay_lost_connection,
        netplay::NETPLAY_ERROR_PLAYER_1_DISCONNECTED => {
            &ui.audio.event_audio.netplay_disconnected[0]
        }
        netplay::NETPLAY_ERROR_PLAYER_2_DISCONNECTED => {
            &ui.audio.event_audio.netplay_disconnected[1]
        }
        netplay::NETPLAY_ERROR_PLAYER_3_DISCONNECTED => {
            &ui.audio.event_audio.netplay_disconnected[2]
        }
        netplay::NETPLAY_ERROR_PLAYER_4_DISCONNECTED => {
            &ui.audio.event_audio.netplay_disconnected[3]
        }
        _ => panic!("Invalid netplay error"),
    };
    if !unsafe {
        sdl3_sys::audio::SDL_PutAudioStreamData(
            ui.audio.event_audio_stream,
            sound.as_ptr() as *const std::ffi::c_void,
            sound.len() as i32,
        )
    } {
        panic!("Could not play audio");
    }
}

pub fn play_pak_switch(ui: &ui::Ui, pak: device::controller::PakType) {
    if ui.audio.event_audio_stream.is_null() {
        return;
    }

    let sound = match pak {
        device::controller::PakType::RumblePak => &ui.audio.event_audio.rumblepak,
        device::controller::PakType::MemPak => &ui.audio.event_audio.mempak,
        device::controller::PakType::TransferPak => &ui.audio.event_audio.transferpak,
        _ => panic!("Invalid pak type"),
    };
    if !unsafe {
        sdl3_sys::audio::SDL_PutAudioStreamData(
            ui.audio.event_audio_stream,
            sound.as_ptr() as *const std::ffi::c_void,
            sound.len() as i32,
        )
    } {
        panic!("Could not play audio");
    }
}

pub fn play_audio(device: &device::Device, dram_addr: usize, length: u64) {
    if device.ui.audio.audio_stream.is_null() {
        return;
    }

    let mut primary_buffer: Vec<i16> = vec![0; length as usize / 2];
    let mut i = 0;
    while i < length as usize / 2 {
        // Left channel
        primary_buffer[i] = *device.rdram.mem.get(dram_addr + (i * 2) + 2).unwrap_or(&0) as i16
            | ((*device.rdram.mem.get(dram_addr + (i * 2) + 3).unwrap_or(&0) as i16) << 8);

        // Right channel
        primary_buffer[i + 1] = *device.rdram.mem.get(dram_addr + (i * 2)).unwrap_or(&0) as i16
            | ((*device.rdram.mem.get(dram_addr + (i * 2) + 1).unwrap_or(&0) as i16) << 8);
        i += 2;
    }

        // === SOFTWARE MASTER VOLUME ===
    // Read the cached gain set by Swift / engine_set_initial_gain
    let mut g = f32::from_bits(GAIN_BITS.load(Ordering::SeqCst));
    if !g.is_finite() { g = 1.0; }
    if g <= 0.0 {
        // Hard mute: zero out samples
        for s in &mut primary_buffer { *s = 0; }
    } else if g < 2.0 - f32::EPSILON && (g - 1.0).abs() > f32::EPSILON {
        // Scale samples and saturate to i16
        for s in &mut primary_buffer {
            let v = (*s as f32) * g;
            *s = v.clamp(i16::MIN as f32, i16::MAX as f32) as i16;
        }
    }
    // =================================

    let audio_queued =
        unsafe { sdl3_sys::audio::SDL_GetAudioStreamQueued(device.ui.audio.audio_stream) } as f64;
    let acceptable_latency = (device.ai.freq as f64 * 0.2) * 4.0;
    let min_latency = (device.ai.freq as f64 * 0.02) * 4.0;

    if audio_queued < min_latency {
        let silence_buffer: Vec<u8> = vec![0; min_latency as usize & !3];
        if !unsafe {
            sdl3_sys::audio::SDL_PutAudioStreamData(
                device.ui.audio.audio_stream,
                silence_buffer.as_ptr() as *const std::ffi::c_void,
                silence_buffer.len() as i32,
            )
        } {
            panic!("Could not play audio");
        }
    }

    if audio_queued < acceptable_latency
        && !unsafe {
            sdl3_sys::audio::SDL_PutAudioStreamData(
                device.ui.audio.audio_stream,
                primary_buffer.as_ptr() as *const std::ffi::c_void,
                primary_buffer.len() as i32 * 2,
            )
        }
    {
        panic!("Could not play audio");
    }
}
