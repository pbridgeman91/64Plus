#![allow(non_snake_case)]
include!(concat!(env!("OUT_DIR"), "/parallel_bindings.rs"));

use crate::{device, ui};
use ab_glyph::{Font, ScaleFont};
use std::{
    ffi::{c_void, CString},
    ptr::null_mut,
    sync::atomic::{AtomicI64, AtomicPtr, Ordering},
};
use sdl3_sys::video;
// ───────────── Shared state Swift can read ─────────────
static EXTERNAL_VIEW_PTR: AtomicPtr<c_void> = AtomicPtr::new(null_mut());
static METAL_VIEW_TAG:   AtomicI64          = AtomicI64::new(-1);
pub static mut WINDOW_PTR: *mut SDL_Window = std::ptr::null_mut();

use objc::{msg_send, sel, sel_impl};
use core_graphics::geometry::CGSize;
use objc::runtime::{Object, BOOL}; // ✅ ADD Class here
use sdl3_sys::metal;            // <-- gives us SDL_Metal_GetLayer
use std::ffi::c_long;
//use crate::ui::video::video::SDL_Window;
use sdl3_sys::everything::SDL_Window;
use sdl3_sys::init;     // for SDL_Quit

// add:
use std::sync::atomic::AtomicBool;

static SUSPENDED: AtomicBool = AtomicBool::new(false);



/// Swift:  @_silgen_name("get_external_view")
#[unsafe(no_mangle)]
pub extern "C" fn get_external_view() -> *mut c_void {
    EXTERNAL_VIEW_PTR.load(Ordering::SeqCst)
}

/// Swift:  @_silgen_name("get_metal_view_tag")
#[unsafe(no_mangle)]
pub extern "C" fn get_metal_view_tag() -> i64 {
    METAL_VIEW_TAG.load(Ordering::SeqCst)
}

#[unsafe(no_mangle)]
pub extern "C" fn shutdown() {
    unsafe {
        // 3️⃣ Now destroy the SDL window safely
        println!("[n64Plus_close] Destroying SDL window…");
        sdl3_sys::video::SDL_DestroyWindow(WINDOW_PTR);
                // 4️⃣ Reset pointers so future calls are no-ops
                WINDOW_PTR = std::ptr::null_mut();
                EXTERNAL_VIEW_PTR.store(null_mut(), Ordering::SeqCst);
                METAL_VIEW_TAG.store(-1, Ordering::SeqCst);
       }
}
//close game
#[unsafe(no_mangle)]
#[unsafe(no_mangle)]
pub extern "C" fn n64Plus_close() {
    unsafe {
        if WINDOW_PTR.is_null() {
            return;
        }

        println!("[n64Plus_close] Beginning shutdown sequence...");

        // ✅ 1. Tell the emulator we want to quit
        wait_for_emulator_exit();

        // ✅ 2. Only now close the RDP processor
        println!("[n64Plus_close] Closing RDP processor…");
       // rdp_close();

        // ✅ 3. Quit SDL
      //  init::SDL_Quit();

        // ✅ 4. Destroy window
        println!("[n64Plus_close] Destroying SDL window…");
        sdl3_sys::video::SDL_DestroyWindow(WINDOW_PTR);
        WINDOW_PTR = std::ptr::null_mut();
        EXTERNAL_VIEW_PTR.store(null_mut(), Ordering::SeqCst);
        METAL_VIEW_TAG.store(-1, Ordering::SeqCst);

        println!("[n64Plus_close] Shutdown complete");
    }
}


pub fn wait_for_emulator_exit() {
    unsafe {
        let mut event = std::mem::zeroed::<sdl3_sys::events::SDL_Event>();

        // SAFELY assign the event type using `common.type` (no underscore!)
        (*(&mut event as *mut _ as *mut sdl3_sys::events::SDL_CommonEvent)).r#type =
            sdl3_sys::everything::SDL_EventType::WINDOW_CLOSE_REQUESTED.into();

        sdl3_sys::events::SDL_PushEvent(&mut event);
    }

    // Wait until the emulator main loop exits
    loop {
        let callback = unsafe { rdp_check_callback() };
        if !callback.emu_running {
            break;
        }

        std::thread::sleep(std::time::Duration::from_millis(16));
        unsafe { sdl3_sys::events::SDL_PumpEvents() };
    }
}




pub fn get_window() -> Option<*mut SDL_Window> {
    unsafe {
        if WINDOW_PTR.is_null() {
            None
        } else {
            Some(WINDOW_PTR)
        }
    }
}

/// Swift:  @_silgen_name("get_metal_view_tag")
#[unsafe(no_mangle)]
pub extern "C" fn resize_window(width: i32, height: i32) {
    if let Some(window) = get_window() {
        unsafe{
        sdl3_sys::video::SDL_SetWindowSize(window, width, height);
        }
        println!("🛠 [resize_window] SDL_SetWindowSize → {width}×{height}");
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn create_sdl_window_from_swift(
    width: i32,
    height: i32,
    fullscreen: bool,
) -> *mut std::ffi::c_void {
    ui::sdl_init(sdl3_sys::init::SDL_INIT_VIDEO);

    let title = std::ffi::CString::new("n64Plus").unwrap();
    let mut flags = sdl3_sys::video::SDL_WINDOW_VULKAN
        | sdl3_sys::video::SDL_WINDOW_RESIZABLE
        | sdl3_sys::video::SDL_WINDOW_INPUT_FOCUS;

    if fullscreen {
       // flags |= sdl3_sys::video::SDL_WINDOW_FULLSCREEN;
    }

    let window = unsafe {
        sdl3_sys::video::SDL_CreateWindow(title.as_ptr(), width, height, flags)
    };

    if window.is_null() {
        let err = unsafe {
            std::ffi::CStr::from_ptr(sdl3_sys::error::SDL_GetError())
                .to_string_lossy()
                .into_owned()
        };
        panic!("Failed to create SDL window from Swift: {err}");
    }

    unsafe {
        video::SDL_ShowWindow(window);
        sdl3_sys::everything::SDL_HideCursor();
        sdl3_sys::everything::SDL_SetHint(
            sdl3_sys::everything::SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS,
            CString::new("1").unwrap().as_ptr(),
        );

        WINDOW_PTR = window; // ✅ This is the missing piece
         // create and stash the Metal UIView*
         let props = unsafe { sdl3_sys::video::SDL_GetWindowProperties(WINDOW_PTR) };

    let metal_view = unsafe {
        sdl3_sys::properties::SDL_GetPointerProperty(
            props,
            sdl3_sys::video::SDL_PROP_WINDOW_UIKIT_WINDOW_POINTER,
            null_mut(),
        )
    };
    EXTERNAL_VIEW_PTR.store(metal_view as *mut _, Ordering::SeqCst);
    }

    window as *mut std::ffi::c_void
}


 // ── Get properties before showing ──
 /*
 let props = unsafe { sdl3_sys::video::SDL_GetWindowProperties(window) };

 // UIView*
 
 let view_ptr = unsafe {
     sdl3_sys::properties::SDL_GetPointerProperty(
         props,
         sdl3_sys::video::SDL_PROP_WINDOW_UIKIT_WINDOW_POINTER,
         null_mut(),
     )
 };
 println!("🧱NEW FUNCTION [video::init] UIView* from SDL: {:?}", view_ptr);
 EXTERNAL_VIEW_PTR.store(view_ptr, Ordering::SeqCst);
*/


pub fn init(device: &mut device::Device) {
    let Some(window) = get_window() else {
        panic!("❌ [init] SDL Window not set before calling init()");
    };

    let gfx_info = GFX_INFO {
        RDRAM: device.rdram.mem.as_mut_ptr(),
        DMEM: device.rsp.mem.as_mut_ptr(),
        RDRAM_SIZE: device.rdram.size,
        DPC_CURRENT_REG: &mut device.rdp.regs_dpc[device::rdp::DPC_CURRENT_REG as usize],
        DPC_START_REG: &mut device.rdp.regs_dpc[device::rdp::DPC_START_REG as usize],
        DPC_END_REG: &mut device.rdp.regs_dpc[device::rdp::DPC_END_REG as usize],
        DPC_STATUS_REG: &mut device.rdp.regs_dpc[device::rdp::DPC_STATUS_REG as usize],
        PAL: device.cart.pal,
        widescreen: device.ui.config.video.widescreen,
        fullscreen: device.ui.video.fullscreen,
        integer_scaling: device.ui.config.video.integer_scaling,
        upscale: device.ui.config.video.upscale,
        crt: device.ui.config.video.crt,
    };

    unsafe { rdp_init(window as *mut c_void, gfx_info) }
}


pub fn close(ui: &ui::Ui) {
    unsafe {
        rdp_close();
        sdl3_sys::video::SDL_DestroyWindow(ui.video.window);
    }
}

pub fn update_screen() {
    if SUSPENDED.load(Ordering::Relaxed) {
        eprintln!("[bg] drop frame");

        return; // skip GPU submits while suspended
    }
    unsafe { rdp_update_screen() }
}


pub fn state_size() -> usize {
    unsafe { rdp_state_size() }
}

pub fn save_state(rdp_state: *mut u8) {
    unsafe { rdp_save_state(rdp_state) }
}

pub fn load_state(device: &mut device::Device, rdp_state: *const u8) {
    let gfx_info = GFX_INFO {
        RDRAM: device.rdram.mem.as_mut_ptr(),
        DMEM: device.rsp.mem.as_mut_ptr(),
        RDRAM_SIZE: device.rdram.size,
        DPC_CURRENT_REG: &mut device.rdp.regs_dpc[device::rdp::DPC_CURRENT_REG as usize],
        DPC_START_REG: &mut device.rdp.regs_dpc[device::rdp::DPC_START_REG as usize],
        DPC_END_REG: &mut device.rdp.regs_dpc[device::rdp::DPC_END_REG as usize],
        DPC_STATUS_REG: &mut device.rdp.regs_dpc[device::rdp::DPC_STATUS_REG as usize],
        PAL: device.cart.pal,
        widescreen: device.ui.config.video.widescreen,
        fullscreen: device.ui.video.fullscreen,
        integer_scaling: device.ui.config.video.integer_scaling,
        upscale: device.ui.config.video.upscale,
        crt: device.ui.config.video.crt,
    };
    unsafe {
        rdp_new_processor(gfx_info);
        rdp_load_state(rdp_state);
        for reg in 0..device::vi::VI_REGS_COUNT {
            rdp_set_vi_register(reg, device.vi.regs[reg as usize])
        }
    }
}

pub fn check_callback(device: &mut device::Device) -> bool {
    let mut speed_limiter_toggled = false;
    let mut callback = unsafe { rdp_check_callback() };
    device.cpu.running = callback.emu_running;
// Always stall the emu while backgrounded so nothing submits.
while SUSPENDED.load(Ordering::Relaxed) {
    std::thread::sleep(std::time::Duration::from_millis(16));
    unsafe { sdl3_sys::events::SDL_PumpEvents() };
}

// Existing logic
if device.netplay.is_none() {
    if callback.save_state { device.save_state = true; }
    else if callback.load_state { device.load_state = true; }

    if device.vi.enable_speed_limiter != callback.enable_speedlimiter {
        speed_limiter_toggled = true;
        device.vi.enable_speed_limiter = callback.enable_speedlimiter;
    }

    while callback.paused {
        std::thread::sleep(std::time::Duration::from_millis(16));
        unsafe { sdl3_sys::events::SDL_PumpEvents() };
        callback = unsafe { rdp_check_callback() };
    }
}


    if callback.lower_volume {
        ui::audio::lower_audio_volume(&mut device.ui);
    } else if callback.raise_volume {
        ui::audio::raise_audio_volume(&mut device.ui);
    }
    speed_limiter_toggled
}

pub fn set_register(reg: u32, value: u32) {
    unsafe {
        rdp_set_vi_register(reg, value);
    }
}

pub fn process_rdp_list() -> u64 {
    unsafe { rdp_process_commands() }
}

pub fn draw_text(
    text: &str,
    renderer: *mut sdl3_sys::render::SDL_Renderer,
    font: &ab_glyph::FontRef,
) {
    // Clear the canvas
    unsafe {
        sdl3_sys::render::SDL_SetRenderDrawColor(
            renderer,
            0,
            0,
            0,
            sdl3_sys::pixels::SDL_ALPHA_OPAQUE,
        );
        sdl3_sys::render::SDL_RenderClear(renderer);
    };

    let text_size = 40.0;
    let (mut w, mut h) = (0, 0);
    unsafe { sdl3_sys::render::SDL_GetRenderOutputSize(renderer, &mut w, &mut h) };
    let x_start = 20.0;
    let y_start = (h / 2) as f32;

    let mut x_offset = 0.0;
    for c in text.chars() {
        let q_glyph_id = font.glyph_id(c);
        let q_glyph = q_glyph_id.with_scale(text_size);

        if let Some(q) = font.outline_glyph(q_glyph) {
            q.draw(|x, y, c| {
                if c > 0.5 {
                    unsafe {
                        sdl3_sys::render::SDL_SetRenderDrawColor(
                            renderer,
                            255,
                            255,
                            255,
                            sdl3_sys::pixels::SDL_ALPHA_OPAQUE,
                        );
                        sdl3_sys::render::SDL_RenderPoint(
                            renderer,
                            x_start + x_offset + x as f32 - q.px_bounds().width()
                                + q.px_bounds().max.x,
                            y_start + y as f32 - q.px_bounds().height() + q.px_bounds().max.y,
                        );
                    };
                }
            });
        }
        x_offset += font.as_scaled(text_size).h_advance(q_glyph_id);
    }

    // Present the canvas
    if !unsafe { sdl3_sys::render::SDL_RenderPresent(renderer) } {
        panic!("Could not present renderer");
    }
}


#[unsafe(no_mangle)]
pub extern "C" fn rdp_suspend() {
    SUSPENDED.store(true, Ordering::SeqCst);
    eprintln!("[bg] suspended={}", SUSPENDED.load(Ordering::Relaxed));

     unsafe { rdp_device_wait_idle() };
}

#[unsafe(no_mangle)]
pub extern "C" fn rdp_resume() {
    eprintln!("[bg] suspended={}", SUSPENDED.load(Ordering::Relaxed));

    SUSPENDED.store(false, Ordering::SeqCst);
}


unsafe extern "C" {
    fn rdp_device_wait_idle();
}