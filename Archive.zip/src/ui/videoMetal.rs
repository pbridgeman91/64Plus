#![allow(non_snake_case)]
include!(concat!(env!("OUT_DIR"), "/parallel_bindings.rs"));

use crate::{device, ui};

use ab_glyph::{Font, ScaleFont};

use core_graphics::geometry::CGSize;
use objc::{msg_send, sel, sel_impl};
use objc::runtime::Object;

use std::{
    ffi::{c_void, CString},
    ptr::null_mut,
    sync::atomic::{AtomicBool, AtomicI64, AtomicPtr, Ordering},
};

use sdl3_sys::{
    everything::SDL_Window,
    events,
    init,
    metal,    // SDL_Metal_* API
    properties,
    render,
    video,
};

use std::ffi::CStr;
use sdl3_sys::vulkan as sdl_vulkan;


// ───────────── Shared cross-language state ─────────────
static EXTERNAL_VIEW_PTR: AtomicPtr<c_void> = AtomicPtr::new(null_mut()); // SDL_uikitmetalview (UIView*)
static METAL_VIEW_TAG:   AtomicI64          = AtomicI64::new(-1);
pub  static mut WINDOW_PTR: *mut SDL_Window = std::ptr::null_mut();

static SUSPENDED: AtomicBool = AtomicBool::new(false);

// A silly-but-stable tag to help Swift debug/find the view if needed.
const METAL_VIEW_TAG_VALUE: i64 = 424_242;

// ========== Metal view / layer helpers ==========

/// Ensure we have an SDL-created Metal view (UIView backed by CAMetalLayer)
/// attached to the SDL window. Cache and return the UIView*.
unsafe fn ensure_metal_view(win: *mut SDL_Window) -> *mut c_void {
    // Already created?
    let cached = EXTERNAL_VIEW_PTR.load(Ordering::SeqCst);
    if !cached.is_null() {
        return cached;
    }

    // Create the SDL_uikitmetalview. SDL attaches it to its own view controller.
    let view = metal::SDL_Metal_CreateView(win) as *mut c_void;
    if view.is_null() {
        eprintln!("❌ SDL_Metal_CreateView returned null: {}", std::ffi::CStr::from_ptr(sdl3_sys::error::SDL_GetError()).to_string_lossy());
        return null_mut();
    }

    // Make sure UIKit layout is up-to-date before Vulkan asks for surface caps.
    video::SDL_SyncWindow(win);

    // Tag it and disable autoresizing masks so Swift Auto Layout can own it if needed.
    let obj = view as *mut Object;
    let _: () = msg_send![obj, setTag: METAL_VIEW_TAG_VALUE];
    let _: () = msg_send![obj, setTranslatesAutoresizingMaskIntoConstraints: false];

    // If you want to be extra careful, you can assert layer type is CAMetalLayer:
    // let layer: *mut c_void = metal::SDL_Metal_GetLayer(view as metal::SDL_MetalView) as *mut c_void;
    // eprintln!("🪞 CAMetalLayer* {:?}", layer);

    METAL_VIEW_TAG.store(METAL_VIEW_TAG_VALUE, Ordering::SeqCst);
    EXTERNAL_VIEW_PTR.store(view, Ordering::SeqCst);
    println!("🧱 [SDL] Metal UIView* created & cached: {:?}", view);

    view
}

/// Get the CAMetalLayer* associated with our SDL Metal view.
#[unsafe(no_mangle)]
pub extern "C" fn sdl_get_metal_layer() -> *mut c_void {
    let view = EXTERNAL_VIEW_PTR.load(Ordering::SeqCst);
    if view.is_null() {
        eprintln!("[sdl_get_metal_layer] no metal view cached");
        return null_mut();
    }
    let layer = unsafe { metal::SDL_Metal_GetLayer(view as metal::SDL_MetalView) } as *mut c_void;
    if layer.is_null() {
        eprintln!("[sdl_get_metal_layer] SDL_Metal_GetLayer returned null");
    } else {
        println!("🪞 [sdl_get_metal_layer] CAMetalLayer* {:?}", layer);
    }
    layer
}

/// Destroy the Metal view explicitly (normally you don’t need to unless tearing down).
#[unsafe(no_mangle)]
pub extern "C" fn sdl_destroy_metal_view() {
    let view = EXTERNAL_VIEW_PTR.swap(null_mut(), Ordering::SeqCst);
    if !view.is_null() {
        unsafe { metal::SDL_Metal_DestroyView(view as metal::SDL_MetalView) };
        METAL_VIEW_TAG.store(-1, Ordering::SeqCst);
        println!("🧹 [SDL] Metal view destroyed");
    }
}

/// Swift uses this to embed the render view. Now it returns the SDL Metal UIView*, not a UIWindow*.
#[unsafe(no_mangle)]
pub extern "C" fn get_external_view() -> *mut c_void {
    EXTERNAL_VIEW_PTR.load(Ordering::SeqCst)
}

#[unsafe(no_mangle)]
pub extern "C" fn get_metal_view_tag() -> i64 {
    METAL_VIEW_TAG.load(Ordering::SeqCst)
}

// ========== Window lifecycle ==========

#[unsafe(no_mangle)]
pub extern "C" fn sdl_sync_window() {
    unsafe {
        if !WINDOW_PTR.is_null() {
            video::SDL_SyncWindow(WINDOW_PTR);
        }
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn n64Plus_close() {
    unsafe {
        if WINDOW_PTR.is_null() {
            return;
        }
        println!("[n64Plus_close] Begin shutdown.");

        // Signal the emu loop to exit gracefully.
        wait_for_emulator_exit();

        // App-specific teardown happens elsewhere (RDP/VK). We just drop window + metal view here.
        println!("[n64Plus_close] Destroying SDL window…");
        video::SDL_DestroyWindow(WINDOW_PTR);
        WINDOW_PTR = std::ptr::null_mut();

        sdl_destroy_metal_view();

        unsafe { sdl_vulkan::SDL_Vulkan_UnloadLibrary(); }


        println!("[n64Plus_close] Done.");
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn shutdown() {
    unsafe {
        println!("[shutdown] Destroying SDL window…");
        video::SDL_DestroyWindow(WINDOW_PTR);
        WINDOW_PTR = std::ptr::null_mut();
        sdl_destroy_metal_view();
    }
}

#[unsafe(no_mangle)]
pub extern "C" fn sdl_get_metal_drawable_size(out_w: *mut u32, out_h: *mut u32) -> bool {
    let view = EXTERNAL_VIEW_PTR.load(Ordering::SeqCst);
    if view.is_null() || out_w.is_null() || out_h.is_null() {
        return false;
    }

    unsafe {
        // UIView* -> layer
        let layer: *mut Object = msg_send![view as *mut Object, layer];
        if layer.is_null() {
            return false;
        }
        // Ensure it’s CAMetalLayer (it is, we created it via SDL_Metal_CreateView).
        let mut ds: CGSize = std::mem::zeroed();
        ds = msg_send![layer, drawableSize];

        // Fallback if iOS reports 0 during transient layouts.
        let mut w = ds.width.round() as u32;
        let mut h = ds.height.round() as u32;
        if w == 0 || h == 0 {
            // use bounds * contentsScale
            let bounds: core_graphics::geometry::CGRect = msg_send![view as *mut Object, bounds];
            let scale: f64 = msg_send![layer, contentsScale];
            w = (bounds.size.width  * scale) as u32;
            h = (bounds.size.height * scale) as u32;
        }
        *out_w = w;
        *out_h = h;
        true
    }
}


/// Swift creates the SDL window through here and we immediately create the SDL Metal view.
/// Returns the SDL_Window* as an opaque pointer (if Swift needs it) but Swift should call
/// `get_external_view()` to embed the actual UIView*.
#[unsafe(no_mangle)]
pub extern "C" fn create_sdl_window_from_swift(width: i32, height: i32, fullscreen: bool) -> *mut c_void {
    ui::sdl_init(init::SDL_INIT_VIDEO);

    let title = CString::new("n64Plus").unwrap();
    // On iOS, SDL will own a full-size, single UIWindow. We still set flags correctly.
    let mut flags = video::SDL_WINDOW_VULKAN
        | video::SDL_WINDOW_RESIZABLE
        | video::SDL_WINDOW_INPUT_FOCUS
        | video::SDL_WINDOW_HIGH_PIXEL_DENSITY; // ensure nativeScale drawableSize

    if fullscreen {
        // iOS is full-screen by nature; no-op for now.
        // flags |= video::SDL_WINDOW_FULLSCREEN; // generally unnecessary on iOS
    }

    let window = unsafe { video::SDL_CreateWindow(title.as_ptr(), width, height, flags) };
    if window.is_null() {
        let err = unsafe { std::ffi::CStr::from_ptr(sdl3_sys::error::SDL_GetError()) }
            .to_string_lossy()
            .into_owned();
        panic!("Failed to create SDL window: {err}");
    }

    unsafe {
        // Basic window setup
        video::SDL_ShowWindow(window);
        sdl3_sys::everything::SDL_HideCursor();
        sdl3_sys::everything::SDL_SetHint(
            sdl3_sys::everything::SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS,
            CString::new("1").unwrap().as_ptr(),
        );

        WINDOW_PTR = window;

        // Create and cache the Metal view now so Vulkan has a live CAMetalLayer during WSI init.
        let view_ptr = ensure_metal_view(window);
        if view_ptr.is_null() {
            eprintln!("⚠️ Created window but failed to create Metal view. Vulkan init may fail.");
        } else {
            println!("🧱 [SDL] Metal UIView* ready for Swift: {:?}", view_ptr);
        }
    }

    window as *mut c_void
}

// ========== Resize helpers Swift can call (optional) ==========

#[unsafe(no_mangle)]
pub extern "C" fn resize_window(_w: i32, _h: i32) {
    // No-op on iOS. The CAMetalLayer drives size; WSI will query it directly.
    // If you want to “poke” WSI to rebuild, do it via SDL events (which you already do)
    // or add a tiny FFI that just sets your resize flag.
    println!("🛠 [resize_window] (no-op on iOS)");
}

// ========== Emulator glue ==========

pub fn wait_for_emulator_exit() {
    unsafe {
        let mut event = std::mem::zeroed::<events::SDL_Event>();
        (*(&mut event as *mut _ as *mut events::SDL_CommonEvent)).r#type =
            sdl3_sys::everything::SDL_EventType::WINDOW_CLOSE_REQUESTED.into();
        events::SDL_PushEvent(&mut event);
    }

    // Wait until the emulator main loop exits
    loop {
        let callback = unsafe { rdp_check_callback() };
        if !callback.emu_running {
            break;
        }
        std::thread::sleep(std::time::Duration::from_millis(16));
        unsafe { events::SDL_PumpEvents() };
    }
}

pub fn get_window() -> Option<*mut SDL_Window> {
    unsafe { if WINDOW_PTR.is_null() { None } else { Some(WINDOW_PTR) } }
}

pub fn init(device: &mut device::Device) {
    let Some(window) = get_window() else {
        panic!("❌ [init] SDL Window not set before calling init()");
    };

    // GFX_INFO wiring
    let gfx_info = GFX_INFO {
        RDRAM: device.rdram.mem.as_mut_ptr(),
        DMEM: device.rsp.mem.as_mut_ptr(),
        RDRAM_SIZE: device.rdram.size,
        DPC_CURRENT_REG: &mut device.rdp.regs_dpc[device::rdp::DPC_CURRENT_REG as usize],
        DPC_START_REG:   &mut device.rdp.regs_dpc[device::rdp::DPC_START_REG   as usize],
        DPC_END_REG:     &mut device.rdp.regs_dpc[device::rdp::DPC_END_REG     as usize],
        DPC_STATUS_REG:  &mut device.rdp.regs_dpc[device::rdp::DPC_STATUS_REG  as usize],
        PAL: device.cart.pal,
        widescreen:        device.ui.config.video.widescreen,
        fullscreen:        device.ui.video.fullscreen,
        integer_scaling:   device.ui.config.video.integer_scaling,
        upscale:           device.ui.config.video.upscale,
        crt:               device.ui.config.video.crt,
    };

    unsafe {
    let ok = sdl_vulkan::SDL_Vulkan_LoadLibrary(std::ptr::null());
    if !ok {
        let err = CStr::from_ptr(sdl3_sys::error::SDL_GetError())
            .to_string_lossy()
            .into_owned();
        eprintln!("❌ SDL_Vulkan_LoadLibrary failed: {err}");
        // You can early-return here if you want to hard-fail:
        // return;
    }

    // By the time rdp_init() runs, SDL has a live CAMetalLayer via ensure_metal_view().
    unsafe { rdp_init(window as *mut c_void, gfx_info) }
}

}
pub fn close(ui: &ui::Ui) {
    unsafe {
        rdp_close();
        video::SDL_DestroyWindow(ui.video.window);
    }
}

pub fn update_screen() {
    if SUSPENDED.load(Ordering::Relaxed) {
        eprintln!("[bg] drop frame");
        return;
    }
    unsafe { rdp_update_screen() }
}

pub fn state_size() -> usize { unsafe { rdp_state_size() } }
pub fn save_state(rdp_state: *mut u8) { unsafe { rdp_save_state(rdp_state) } }

pub fn load_state(device: &mut device::Device, rdp_state: *const u8) {
    let gfx_info = GFX_INFO {
        RDRAM: device.rdram.mem.as_mut_ptr(),
        DMEM: device.rsp.mem.as_mut_ptr(),
        RDRAM_SIZE: device.rdram.size,
        DPC_CURRENT_REG: &mut device.rdp.regs_dpc[device::rdp::DPC_CURRENT_REG as usize],
        DPC_START_REG:   &mut device.rdp.regs_dpc[device::rdp::DPC_START_REG   as usize],
        DPC_END_REG:     &mut device.rdp.regs_dpc[device::rdp::DPC_END_REG     as usize],
        DPC_STATUS_REG:  &mut device.rdp.regs_dpc[device::rdp::DPC_STATUS_REG  as usize],
        PAL: device.cart.pal,
        widescreen:        device.ui.config.video.widescreen,
        fullscreen:        device.ui.video.fullscreen,
        integer_scaling:   device.ui.config.video.integer_scaling,
        upscale:           device.ui.config.video.upscale,
        crt:               device.ui.config.video.crt,
    };
    unsafe {
        rdp_new_processor(gfx_info);
        rdp_load_state(rdp_state);
        for reg in 0..device::vi::VI_REGS_COUNT {
            rdp_set_vi_register(reg, device.vi.regs[reg as usize])
        }
    }
}

pub fn check_callback(device: &mut device::Device) -> bool {
    let mut speed_limiter_toggled = false;
    let mut callback = unsafe { rdp_check_callback() };
    device.cpu.running = callback.emu_running;

    // Stall while backgrounded
    while SUSPENDED.load(Ordering::Relaxed) {
        std::thread::sleep(std::time::Duration::from_millis(16));
        unsafe { events::SDL_PumpEvents() };
    }

    if device.netplay.is_none() {
        if callback.save_state { device.save_state = true; }
        else if callback.load_state { device.load_state = true; }

        if device.vi.enable_speed_limiter != callback.enable_speedlimiter {
            speed_limiter_toggled = true;
            device.vi.enable_speed_limiter = callback.enable_speedlimiter;
        }

        while callback.paused {
            std::thread::sleep(std::time::Duration::from_millis(16));
            unsafe { events::SDL_PumpEvents() };
            callback = unsafe { rdp_check_callback() };
        }
    }

    if callback.lower_volume {
        ui::audio::lower_audio_volume(&mut device.ui);
    } else if callback.raise_volume {
        ui::audio::raise_audio_volume(&mut device.ui);
    }
    speed_limiter_toggled
}

pub fn set_register(reg: u32, value: u32) { unsafe { rdp_set_vi_register(reg, value); } }
pub fn process_rdp_list() -> u64 { unsafe { rdp_process_commands() } }

// ========== Tiny text helper (unchanged) ==========

pub fn draw_text(text: &str, renderer: *mut render::SDL_Renderer, font: &ab_glyph::FontRef) {
    unsafe {
        render::SDL_SetRenderDrawColor(renderer, 0, 0, 0, sdl3_sys::pixels::SDL_ALPHA_OPAQUE);
        render::SDL_RenderClear(renderer);
    };

    let text_size = 40.0;
    let (mut w, mut h) = (0, 0);
    unsafe { render::SDL_GetRenderOutputSize(renderer, &mut w, &mut h) };
    let x_start = 20.0;
    let y_start = (h / 2) as f32;

    let mut x_offset = 0.0;
    for c in text.chars() {
        let gid = font.glyph_id(c);
        let g = gid.with_scale(text_size);

        if let Some(outlined) = font.outline_glyph(g) {
            outlined.draw(|x, y, cov| {
                if cov > 0.5 {
                    unsafe {
                        render::SDL_SetRenderDrawColor(
                            renderer, 255, 255, 255, sdl3_sys::pixels::SDL_ALPHA_OPAQUE,
                        );
                        render::SDL_RenderPoint(
                            renderer,
                            x_start + x_offset + x as f32 - outlined.px_bounds().width() + outlined.px_bounds().max.x,
                            y_start + y as f32 - outlined.px_bounds().height() + outlined.px_bounds().max.y,
                        );
                    };
                }
            });
        }
        x_offset += font.as_scaled(text_size).h_advance(gid);
    }

    if !unsafe { render::SDL_RenderPresent(renderer) } {
        panic!("Could not present renderer");
    }
}

// ========== App lifecycle (suspend/resume) ==========

#[unsafe(no_mangle)]
pub extern "C" fn rdp_suspend() {
    SUSPENDED.store(true, Ordering::SeqCst);
    eprintln!("[bg] suspended={}", SUSPENDED.load(Ordering::Relaxed));
    unsafe { rdp_device_wait_idle() };
}

#[unsafe(no_mangle)]
pub extern "C" fn rdp_resume() {
    eprintln!("[bg] suspended={}", SUSPENDED.load(Ordering::Relaxed));
    SUSPENDED.store(false, Ordering::SeqCst);
}

#[unsafe(no_mangle)]
pub extern "C" fn wsi_request_resize() {
unsafe {interface_wsi_request_resize()}; 
}

unsafe extern "C" {
    fn rdp_device_wait_idle();
}

unsafe extern "C" {
    fn interface_wsi_request_resize();
}
