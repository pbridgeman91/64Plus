use crate::device;
use crate::netplay;
use crate::ui;
use slint::Model;
//use std::time::Duration;
/* ----------------------- Open ROM ----------------------- */
use std::process::Command;   // make sure this `use` line is near the top of gui.rs
/* ----------------------- Run ROM ----------------------- */

//custom file pciker
use crate::file_picker::AsyncFileDialog;

///new launch rom load rom
use std::ffi::CStr;
use std::os::raw::c_char;
use std::path::PathBuf;


slint::include_modules!();

pub const N64_EXTENSIONS: [&str; 5] = ["n64", "v64", "z64", "7z", "zip"];

#[derive(serde::Deserialize)]
struct GithubData {
    tag_name: String,
}

pub struct NetplayDevice {
    pub peer_addr: std::net::SocketAddr,
    pub player_number: u8,
}

#[derive(Default)]
pub struct GbPaths {
    pub rom: [Option<std::path::PathBuf>; 4],
    pub ram: [Option<std::path::PathBuf>; 4],
}

#[derive(Default)]
pub struct VruChannel {
    pub vru_window_notifier: Option<tokio::sync::mpsc::Sender<Option<Vec<String>>>>,
    pub vru_word_receiver: Option<tokio::sync::mpsc::Receiver<String>>,
}

#[derive(Clone)]
#[derive(Default)]
pub struct GameSettings {
    pub fullscreen: bool,
    pub overclock: bool,
    pub disable_expansion_pak: bool,
    pub cheats: std::collections::HashMap<String, Option<String>>,
}

/*fn check_latest_version(weak: slint::Weak<AppWindow>) {
    let client = reqwest::Client::builder()
        .user_agent(env!("CARGO_PKG_NAME"))
        .build()
        .unwrap();
    let task = client
        .get("https://api.github.com/repos/n64Plus/n64Plus/releases/latest")
        .send();
    tokio::spawn(async move {
        let response = task.await;
        if let Ok(response) = response {
            let data: Result<GithubData, reqwest::Error> = response.json().await;

            let latest_version = if let Ok(data) = data {
                semver::Version::parse(&data.tag_name[1..]).unwrap()
            } else {
                semver::Version::parse(env!("CARGO_PKG_VERSION")).unwrap()
            };
            let current_version = semver::Version::parse(env!("CARGO_PKG_VERSION")).unwrap();
            if current_version < latest_version {
                weak.upgrade_in_event_loop(move |handle| handle.set_has_update(true))
                    .unwrap();
            }
        }
    });
} */

fn local_game_window(app: &AppWindow, controller_paths: &[Option<String>]) {
    let dirs = ui::get_dirs();
    let weak = app.as_weak();
    let controller_paths = controller_paths.to_owned();
    app.on_open_rom_button_clicked(move || {
        let controller_paths = controller_paths.clone();
        weak.upgrade_in_event_loop(move |handle| {
            save_settings(&handle, &controller_paths);
            open_rom(&handle)
        })
        .unwrap();
    });

    let saves_path = dirs.data_dir.join("saves");
    app.on_saves_folder_button_clicked(move || {
        open::that_detached(saves_path.clone()).unwrap();
    });
}

fn input_profiles(config: &ui::config::Config) -> Vec<String> {
    let mut profiles = vec![];
    for key in config.input.input_profiles.keys() {
        profiles.push(key.clone())
    }
    profiles
}

fn settings_window(app: &AppWindow, config: &ui::config::Config) {
    app.set_integer_scaling(config.video.integer_scaling);
    app.set_fullscreen(config.video.fullscreen);
    app.set_widescreen(config.video.widescreen);
    app.set_apply_crt_shader(config.video.crt);
    app.set_overclock_n64_cpu(config.emulation.overclock);
    app.set_disable_expansion_pak(config.emulation.disable_expansion_pak);
    let combobox_value = match config.video.upscale {
        1 => 0,
        2 => 1,
        4 => 2,
        _ => 0,
    };
    app.set_resolution(combobox_value);

    if let Some(rom_dir_str) = config.rom_dir.to_str() {
        app.set_rom_dir(rom_dir_str.into());
    }
}

fn update_input_profiles(weak: &slint::Weak<AppWindow>, config: &ui::config::Config) {
    let profiles = input_profiles(config);
    let config_bindings = config.input.input_profile_binding.clone();
    let weak2 = weak.clone();
    weak.upgrade_in_event_loop(move |handle| {
        let profile_bindings = slint::VecModel::default();
        for (i, input_profile_binding) in handle.get_selected_profile_binding().iter().enumerate() {
            let currently_selected = handle
                .get_input_profiles()
                .row_data(input_profile_binding as usize)
                .unwrap_or(config_bindings[i].clone().into())
                .to_string();
            let position = profiles
                .iter()
                .position(|profile| *profile == currently_selected);
            profile_bindings.push(position.unwrap() as i32);
        }

        let input_profiles = slint::VecModel::default();
        for profile in profiles {
            input_profiles.push(profile.into());
        }
        let input_profiles_model: std::rc::Rc<slint::VecModel<slint::SharedString>> =
            std::rc::Rc::new(input_profiles);
        handle.set_input_profiles(slint::ModelRc::from(input_profiles_model));

        let input_profile_binding_model: std::rc::Rc<slint::VecModel<i32>> =
            std::rc::Rc::new(profile_bindings);
        handle.set_selected_profile_binding(slint::ModelRc::from(input_profile_binding_model));

        // this is a workaround to make the input profile combobox update
        handle.set_blank_profiles(true);
        slint::Timer::single_shot(std::time::Duration::from_millis(200), move || {
            weak2
                .upgrade_in_event_loop(move |handle| {
                    handle.set_blank_profiles(false);
                })
                .unwrap();
        });
    })
    .unwrap();
}

fn controller_window(
    app: &AppWindow,
    config: &ui::config::Config,
    controller_names: &Vec<String>,
    controller_paths: &[Option<String>],
) {
    let controller_enabled_model: std::rc::Rc<slint::VecModel<bool>> = std::rc::Rc::new(
        slint::VecModel::from(config.input.controller_enabled.to_vec()),
    );
    app.set_emulate_vru(config.input.emulate_vru);

    app.set_controller_enabled(slint::ModelRc::from(controller_enabled_model));

    let transferpak_enabled_model: std::rc::Rc<slint::VecModel<bool>> =
        std::rc::Rc::new(slint::VecModel::from(config.input.transfer_pak.to_vec()));
    app.set_transferpak(slint::ModelRc::from(transferpak_enabled_model));

    update_input_profiles(&app.as_weak(), config);

    let controllers = slint::VecModel::default();
    for controller in controller_names {
        controllers.push(controller.into());
    }
    let controller_names_model: std::rc::Rc<slint::VecModel<slint::SharedString>> =
        std::rc::Rc::new(controllers);
    app.set_controller_names(slint::ModelRc::from(controller_names_model));

    let selected_controllers = slint::VecModel::default();
    for selected in config.input.controller_assignment.iter() {
        let mut found = false;
        for (i, path) in controller_paths.iter().enumerate() {
            if selected == path {
                selected_controllers.push(i as i32);
                found = true;
                continue;
            }
        }
        if !found {
            selected_controllers.push(0);
        }
    }
    let selected_controllers_model: std::rc::Rc<slint::VecModel<i32>> =
        std::rc::Rc::new(selected_controllers);
    app.set_selected_controller(slint::ModelRc::from(selected_controllers_model));

 /* -------------  “Configure Input Profile” button ------------------------- */

 let weak_app = app.as_weak();       // only a weak ptr is captured → Send

 app.on_input_profile_button_clicked(move || {
     /* ── 1️⃣  Slint dialog to ask for name + dinput flag ───────────────── */
     let dialog       = InputProfileDialog::new().unwrap();
     let weak_dialog  = dialog.as_weak();
     let weak_app2    = weak_app.clone();

/* … unchanged code … */

dialog.on_profile_creation_button_clicked(move || {
    // clone *inside* the outer closure so we can still use weak_app2 later
    let weak_app_outer = weak_app2.clone();
    let weak_dlg2      = weak_dialog.clone();

    weak_dlg2.upgrade_in_event_loop(move |dlg| {
        /* -------- grab text + spawn wizard (unchanged) -------- */
        let profile_name: String = dlg.get_profile_name().into();
        let dinput        = dlg.get_dinput();
        dlg.hide().unwrap();

        let exe = std::env::current_exe().expect("cannot find own executable");
        let mut cmd = std::process::Command::new(exe);
        cmd.arg("--configure-input-profile").arg(&profile_name);
        if dinput { cmd.arg("--use-dinput"); }

        // this clone is now valid because weak_app_outer is still alive
        let weak_for_thread = weak_app_outer.clone();
        std::thread::spawn(move || {
            let _ = cmd.status();

            slint::invoke_from_event_loop(move || {
                let game_ui = ui::Ui::new();
                update_input_profiles(&weak_for_thread, &game_ui.config);
            }).unwrap();
        });
    }).unwrap();
});

/* … unchanged code … */


     dialog.show().unwrap();
 });
}

pub fn save_settings(app: &AppWindow, controller_paths: &[Option<String>]) {
    let mut config = ui::config::Config::new();
    config.video.integer_scaling = app.get_integer_scaling();
    config.video.fullscreen = app.get_fullscreen();
    config.video.widescreen = app.get_widescreen();
    config.video.crt = app.get_apply_crt_shader();
    config.emulation.overclock = app.get_overclock_n64_cpu();
    config.emulation.disable_expansion_pak = app.get_disable_expansion_pak();
    let upscale_values = [1, 2, 4];
    config.video.upscale = upscale_values[app.get_resolution() as usize];

    config.input.emulate_vru = app.get_emulate_vru();
    for (i, controller_enabled) in app.get_controller_enabled().iter().enumerate() {
        config.input.controller_enabled[i] = controller_enabled;
    }
    for (i, transferpak_enabled) in app.get_transferpak().iter().enumerate() {
        config.input.transfer_pak[i] = transferpak_enabled;
    }
    for (i, input_profile_binding) in app.get_selected_profile_binding().iter().enumerate() {
        config.input.input_profile_binding[i] = app
            .get_input_profiles()
            .row_data(input_profile_binding as usize)
            .unwrap()
            .to_string();
    }

    for (i, selected_controller) in app.get_selected_controller().iter().enumerate() {
        config.input.controller_assignment[i] =
            controller_paths[selected_controller as usize].clone();
    }
}

fn about_window(app: &AppWindow) {
    app.on_wiki_button_clicked(move || {
        open::that_detached("https://github.com/n64Plus/").unwrap();
    });
    app.on_discord_button_clicked(move || {
        open::that_detached("https://discord.gg/").unwrap();
    });
    app.on_patreon_button_clicked(move || {
        open::that_detached("https://patreon.com/0").unwrap();
    });
    app.on_github_sponsors_button_clicked(move || {
        open::that_detached("https://github.com/sponsors/").unwrap();
    });
    app.on_source_code_button_clicked(move || {
        open::that_detached("https://github.com/n64Plus/n64Plus").unwrap();
    });
    app.on_newversion_button_clicked(move || {
        open::that_detached("https://github.com/n64Plus/n64Plus/").unwrap();
    }); 
    let credits = format!(
        "Developed by Patrick Bridgeman\n
        Version: 1.0",
    );
    app.set_version(credits.into());
  //  check_latest_version(app.as_weak());
}

pub fn app_window() {
    let app = AppWindow::new().unwrap();
    about_window(&app);
    let mut controller_paths;
    {
        let game_ui = ui::Ui::new();
        let mut controller_names = ui::input::get_controller_names(&game_ui);
        controller_names.insert(0, "None".into());
        controller_paths = ui::input::get_controller_paths(&game_ui);
        controller_paths.insert(0, None);
        settings_window(&app, &game_ui.config);
        controller_window(&app, &game_ui.config, &controller_names, &controller_paths);
    }
    local_game_window(&app, &controller_paths);
    ui::netplay::netplay_window(&app, &controller_paths);
    ui::cheats::cheats_window(&app);
    app.run().unwrap();
    save_settings(&app, &controller_paths);
}



pub fn run_rom(
    gb_paths: GbPaths,
    file_path: std::path::PathBuf,
    mut game_settings: GameSettings,
    vru_channel: VruChannel,
    netplay: Option<NetplayDevice>,
    weak: slint::Weak<AppWindow>,
) {
    #[cfg(not(target_os = "ios"))]
    weak.upgrade_in_event_loop(|h| h.set_game_running(true)).ok();
    

    // Direct game launch
    let mut device = device::Device::new();
    device.ui.config.rom_dir = file_path.parent().unwrap().to_path_buf();

    for i in 0..4 {
        if gb_paths.rom[i].is_some() && gb_paths.ram[i].is_some() {
            device.transferpaks[i].cart.rom =
                std::fs::read(gb_paths.rom[i].as_ref().unwrap()).unwrap();
            device.transferpaks[i].cart.ram =
                std::fs::read(gb_paths.ram[i].as_ref().unwrap()).unwrap();
        }
    }

    device.vru_window.window_notifier = vru_channel.vru_window_notifier;
    device.vru_window.word_receiver = vru_channel.vru_word_receiver;

    if let Some(rom_contents) = device::get_rom_contents(file_path.as_path()) {
        if let Some(net_dev) = netplay {
            device.netplay = Some(netplay::init(net_dev.peer_addr, net_dev.player_number));
        } else {
            let crc = ui::storage::get_game_crc(&rom_contents);
            let cheats = ui::config::Cheats::new();
            game_settings.cheats = cheats.cheats.get(&crc).cloned().unwrap_or_default();
        }

        // **Run game directly**
        device::run_game(&mut device, rom_contents, game_settings);

        if device.netplay.is_some() {
            netplay::close(&mut device);
        }
    }

    if let Some(notifier) = device.vru_window.window_notifier {
        let _ = notifier.try_send(None);
    }

    let rom_dir = device.ui.config.rom_dir.clone();
    #[cfg(not(target_os = "ios"))]
    weak.upgrade_in_event_loop(move |h| {
        if let Some(s) = rom_dir.to_str() {
            h.set_rom_dir(s.into());
        }
        h.set_game_running(false);
    })
    .unwrap();
}


/* ----------------------- Open ROM ----------------------- */
fn open_rom(app: &AppWindow) {
    let rom_dir    = app.get_rom_dir();
    let fullscreen = app.get_fullscreen();
    let weak       = app.as_weak();

    // ── async file‑picker ────────────────────────────────────────────────
    // ── async file‑picker ────────────────────────────────────────────────
    let picker = {
        let dlg = if !rom_dir.is_empty() && std::fs::metadata(&rom_dir).is_ok() {
            // pass &str so it AsRef<Path>
            AsyncFileDialog::new().set_directory(&*rom_dir)
        } else {
            AsyncFileDialog::new()
        };
        dlg.set_title("Select ROM")
            .add_filter("ROM files", &ui::gui::N64_EXTENSIONS)
            .pick_file()
    };

    tokio::spawn(async move {
        if let Some(file) = picker.await {
            let rom_path = file.path().to_owned();   // needs static lifetime for the thread

            /* 1️⃣  Hide the launcher & flag “game running” */
            let _ = weak.upgrade_in_event_loop(|h| {
                h.set_game_running(true);
                h.set_menu_visible(false);
            });

            /* 2️⃣  Build the command line */
            let mut cmd = Command::new(
                std::env::current_exe().expect("cannot find own executable"),
            );
            cmd.arg(&rom_path);
            if fullscreen {
                cmd.arg("--fullscreen");
            }

            /* 3️⃣  Run the emulator in a helper thread */
            std::thread::spawn(move || {
                let _ = cmd.status();           // wait for the game to exit

                /* 4️⃣  Show the launcher again */
                let _ = weak.upgrade_in_event_loop(|h| {
                    h.set_game_running(false);
                    h.set_menu_visible(true);
                });
            });
        }
    });
}





//////////iOS
#[unsafe(no_mangle)]
pub unsafe extern "C" fn run_rom_embedded_with_settings(
    path: *const c_char,                   // C-string from Swift
    disable_expansion_pak: bool,
    fullscreen: bool,
    overclock: bool,
) {
    // ── 1️⃣  C-string → &str → PathBuf ────────────────────────────────
    let rom_path = CStr::from_ptr(path).to_str().unwrap();
    let file_path = PathBuf::from(rom_path);

    // ── 2️⃣  Blank TransferPak paths (same as desktop default) ────────
    let gb_paths = GbPaths::default();     // requires #[derive(Default)] on GbPaths

    // ── 3️⃣  Build GameSettings with the flags coming from Swift ──────
    let mut game_settings = GameSettings::default();   // #[derive(Default)] or manual impl
    game_settings.disable_expansion_pak = disable_expansion_pak;
    game_settings.fullscreen            = fullscreen;
    game_settings.overclock             = overclock;

    // ── 4️⃣  No VRU / netplay on iOS right now ────────────────────────
    let vru      = VruChannel::default(); // or VruChannel { vru_window_notifier: None, vru_word_receiver: None }
    let netplay  = None;
    let dummy = slint::Weak::<AppWindow>::default();

    // ── 5️⃣  Launch the game! ─────────────────────────────────────────
    run_rom(gb_paths, file_path, game_settings, vru, netplay, dummy);
}


use std::{net::ToSocketAddrs};

unsafe extern "C" { fn SDL_SetMainReady(); }

// iOS-only: run a ROM with netplay, no Slint involved
#[unsafe(no_mangle)]
pub unsafe extern "C" fn run_rom_embedded_with_netplay(
    path: *const c_char,         // C string: ROM path
    host_port: *const c_char,    // C string: "ws://10.240.1.186:45001" or "10.240.1.186:45001"
    player_number: u8,
    disable_expansion_pak: bool,
    fullscreen: bool,
    overclock: bool,
) {
    use std::path::Path;
    // ---- Parse inputs ----
    let rom_path = {
        let s = CStr::from_ptr(path).to_str().expect("bad ROM path");
        PathBuf::from(s)
    };
    let host_port_raw = CStr::from_ptr(host_port).to_str().expect("bad host:port");

    // Prepare GameSettings
    let mut game_settings = ui::gui::GameSettings {
        fullscreen,
        overclock,
        disable_expansion_pak,
        cheats: Default::default(),
    };

    // Prepare netplay address
    let mut cleaned = host_port_raw
        .trim_start_matches("ws://")
        .trim_start_matches("wss://")
        .to_string();
    if let Some(pos) = cleaned.find(['/', '?']) {
        cleaned.truncate(pos);
    }
    // If there are multiple colons (e.g., IPv6 w/port got mangled), try to keep last :port
    if cleaned.matches(':').count() > 1 {
        if let Some((host, port)) = cleaned.rsplit_once(':') {
            cleaned = format!("{host}:{port}");
        }
    }

    // Defer the actual launch to the iOS main queue (UIKit/SDL requirement)
    #[cfg(target_os = "ios")]
    {
        use dispatch::Queue;

        let rp = rom_path;
        let hp = cleaned;
        let pn = player_number;
        let gs = game_settings;

        Queue::main().exec_async(move || {
            unsafe { SDL_SetMainReady(); }
            ui::sdl_init(sdl3_sys::init::SDL_INIT_VIDEO | sdl3_sys::init::SDL_INIT_GAMEPAD);

            // Build device like run_rom()
            let mut device = device::Device::new();
let parent = rp.parent().unwrap_or(Path::new("."));
device.ui.config.rom_dir = parent.to_path_buf();
            // VRU/default channels (no Slint)
            let vru = ui::gui::VruChannel::default();

            if let Some(rom_contents) = device::get_rom_contents(&rp) {
                // Cheats only when not doing netplay
                // (your desktop run_rom does this)
                // Here we're always enabling netplay, so set netplay:
                // Resolve host:port → SocketAddr
                let peer_addr: std::net::SocketAddr = hp.parse().unwrap_or_else(|_| {
                    std::net::ToSocketAddrs::to_socket_addrs(&hp).ok()
                        .and_then(|mut it| it.next())
                        .expect("peer must resolve to a socket address")
                });
                device.netplay = Some(netplay::init(peer_addr, pn));

                // (Optional) if you want cheats even with netplay removed, keep as-is:
                // else {
                //     let crc = ui::storage::get_game_crc(&rom_contents);
                //     let cheats = ui::config::Cheats::new();
                //     game_settings.cheats = cheats.cheats.get(&crc).cloned().unwrap_or_default();
                // }

                // Run the game
                device::run_game(&mut device, rom_contents, gs);

                // Close netplay if used
                if device.netplay.is_some() {
                    netplay::close(&mut device);
                }
            } else {
                eprintln!("❌ Could not read ROM: {:?}", rp);
            }

            // VRU cleanup
            if let Some(notifier) = device.vru_window.window_notifier {
                let _ = notifier.try_send(None);
            }
        });
    }

    // Non-iOS fallback: run inline (handy if you target other platforms with same symbol)
    #[cfg(not(target_os = "ios"))]
    {
        unsafe { SDL_SetMainReady(); }
        ui::sdl_init(sdl3_sys::init::SDL_INIT_VIDEO | sdl3_sys::init::SDL_INIT_GAMEPAD);

        let mut device = device::Device::new();
        device.ui.config.rom_dir = rom_path.parent().unwrap_or_else(|| PathBuf::from(".").as_path()).to_path_buf();

        let vru = ui::gui::VruChannel::default();

        if let Some(rom_contents) = device::get_rom_contents(&rom_path) {
            let peer_addr: std::net::SocketAddr = cleaned.parse().unwrap_or_else(|_| {
                std::net::ToSocketAddrs::to_socket_addrs(&cleaned).ok()
                    .and_then(|mut it| it.next())
                    .expect("peer must resolve to a socket address")
            });
            device.netplay = Some(netplay::init(peer_addr, player_number));

            device::run_game(&mut device, rom_contents, game_settings);

            if device.netplay.is_some() {
                netplay::close(&mut device);
            }
        } else {
            eprintln!("❌ Could not read ROM: {:?}", rom_path);
        }

        if let Some(notifier) = device.vru_window.window_notifier {
            let _ = notifier.try_send(None);
        }
    }
}



////////////////////////
/////netplay

/*
use crate::SocketAddr;
use crate::c_void;
use std::rc::Weak;

#[unsafe(no_mangle)]
pub unsafe extern "C" fn n64Plus_start_netplay(
    rom_path: *const c_char,
    peer_addr: *const c_char,
    player_number: u8,
) -> *mut c_void {
    // 1️⃣ Convert the C strings into Rust types
    let rom_str = CStr::from_ptr(rom_path).to_str().unwrap();
    let peer_str = CStr::from_ptr(peer_addr).to_str().unwrap();
    let socket_addr: SocketAddr = peer_str.parse().unwrap();

    // 2️⃣ Build the NetplayDevice
    let net_dev = NetplayDevice {
        peer_addr: socket_addr,
        player_number,
    };

    // 3️⃣ Prepare default paths & settings (adjust fullscreen/overclock if needed)
    let gb_paths = GbPaths::default();
    let vru = VruChannel::default();
    let mut settings = GameSettings::default();
    settings.fullscreen = true;
    settings.overclock = true;
    settings.disable_expansion_pak = false;

    // 4️⃣ Call the core run_rom with netplay enabled
    run_rom(
        gb_paths,
        PathBuf::from(rom_str),
        settings,
        vru,
        Some(net_dev),
        Weak::<AppWindow>::default(),
    );

    // 5️⃣ Return null (no view pointer needed on iOS)
    std::ptr::null_mut()
}
*/


/*
use std::net::SocketAddr;
use std::rc::Weak;

#[unsafe(no_mangle)]
pub unsafe extern "C" fn n64Plus_start_netplay(
    path: *const c_char,
    disable_expansion_pak: bool,
    fullscreen: bool,
    overclock: bool,
    peer_addr: *const c_char,
    player_number: u8,
) {
    // 1️⃣ ROM path
    let rom_str = CStr::from_ptr(path)
        .to_str().expect("Invalid UTF-8 in ROM path");
    let file_path = PathBuf::from(rom_str);

    // 2️⃣ Default GB paths
    let gb_paths = GbPaths::default();

    // 3️⃣ Game settings
    let mut settings = GameSettings::default();
    settings.disable_expansion_pak = disable_expansion_pak;
    settings.fullscreen            = fullscreen;
    settings.overclock             = overclock;

    // 4️⃣ Parse peer_addr into a SocketAddr
// 4️⃣ Parse peer_addr into a SocketAddr
let peer_str = CStr::from_ptr(peer_addr)
    .to_str()
    .expect("Invalid UTF-8 in peer address");

// FIRST try it exactly as-is
let socket_addr: SocketAddr = match peer_str.parse() {
    Ok(addr) => addr,
    Err(_) => {
        // ────────── sanitize common client mistakes ──────────
        // 1. Strip ws:// or wss://
        let mut cleaned = peer_str
            .trim_start_matches("ws://")
            .trim_start_matches("wss://");

        // 2. If there’s a slash, cut everything after it (path/query)
        if let Some(pos) = cleaned.find(['/', '?']) {
            cleaned = &cleaned[..pos];
        }

        // 3. If there are *two* colons (host:port1:port2),
        //    keep only host:last_port
        if cleaned.matches(':').count() > 1 {
            if let Some((host, port)) = cleaned.rsplit_once(':') {
                cleaned = &format!("{host}:{port}");
            }
        }

        cleaned
            .parse()
            .expect("peer must be host:port (e.g. \"example.com:45003\")")
    }
};


    // 5️⃣ Wrap into your local NetplayDevice
    let net_dev = NetplayDevice {
        peer_addr: socket_addr,
        player_number,
    };

    // 6️⃣ No VRU on iOS; dummy window
    let vru   = VruChannel::default();
    let dummy = slint::Weak::<AppWindow>::default();

    // 7️⃣ Launch netplay
    run_rom(gb_paths, file_path, settings, vru, Some(net_dev), dummy);
}
*/