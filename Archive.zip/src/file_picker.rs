//! Cross‑platform wrapper for file‑open/save dialogs.
//! • Desktop = use `rfd` normally
//! • iOS     = stub that compiles (returns `None`)

#[cfg(not(target_os = "ios"))]
pub use rfd::AsyncFileDialog;               // ← desktops keep the real thing

// ─────────────── iOS stub ───────────────
#[cfg(target_os = "ios")]
pub struct AsyncFileDialog;

#[cfg(target_os = "ios")]
impl AsyncFileDialog {
    pub fn new() -> Self                               { AsyncFileDialog }
    pub fn set_directory(self, _d: impl AsRef<std::path::Path>) -> Self { self }
    pub fn set_title     (self, _t: impl AsRef<str>)  -> Self { self }
    pub fn add_filter    (self, _n: impl AsRef<str>, _e: &[impl AsRef<str>]) -> Self { self }

    /// **TODO**: call a real iOS picker here.  
    /// For now we just print a message and return `None`
    pub async fn pick_file(self) -> Option<IOSFileHandle> {
        eprintln!("iOS: file dialogs are not implemented yet.");
        None
    }
}

/// Dummy handle so the rest of the code compiles unchanged
#[cfg(target_os = "ios")]
#[derive(Clone, Debug)]
pub struct IOSFileHandle {
    path: std::path::PathBuf,
}
#[cfg(target_os = "ios")]
impl IOSFileHandle {
    pub fn path(&self) -> &std::path::Path { &self.path }
}
