use crate::{device, ui};
#[cfg(target_arch = "aarch64")]
use device::__m128i;
use serde::de::{Deserialize, Deserializer, SeqAccess, Visitor};
use serde::ser::{Serialize, SerializeSeq, Serializer};
#[cfg(target_arch = "x86_64")]
use std::arch::x86_64::*;


use stacker;
use serde::Deserialize as _;

// Grow stack, then decode using serde_stacker to reduce recursion pressure further.
fn decode_device_with_grown_stack(bytes: &[u8]) -> Result<Box<device::Device>, postcard::Error> {
    // Tune these two numbers if needed:
    const RED_ZONE: usize = 64 * 1024;      // how close we can get before growing
    const TARGET:   usize = 8 * 1024 * 1024; // desired stack size while inside the closure

    // We need to shuttle the result out of the closure.
    let mut out: Option<Box<device::Device>> = None;
    // `stacker::maybe_grow` returns the closure's result (we thread postcard::Error through).
    let res: Result<(), postcard::Error> = stacker::maybe_grow(RED_ZONE, TARGET, || {
        let mut base = postcard::Deserializer::from_bytes(bytes);
        let de = serde_stacker::Deserializer::new(&mut base);
        let dev: device::Device = device::Device::deserialize(de)?;
        out = Some(Box::new(dev));
        Ok(())
    });

    match res {
        Ok(()) => Ok(out.expect("decode_device_with_grown_stack produced no value")),
        Err(e) => Err(e),
    }
}

// -----------------------------
// SIMD (__m128i) serializers
// -----------------------------

struct M128iArrayVisitor<const N: usize>;

impl<'de, const N: usize> Visitor<'de> for M128iArrayVisitor<N> {
    type Value = [__m128i; N];

    fn expecting(&self, formatter: &mut std::fmt::Formatter) -> std::fmt::Result {
        formatter.write_str(&format!("an array of {N} 128-bit integers"))
    }

    fn visit_seq<A>(self, mut seq: A) -> Result<Self::Value, A::Error>
    where
        A: SeqAccess<'de>,
    {
        let mut arr: [__m128i; N] = [device::zero_m128i(); N];
        for (index, item) in arr.iter_mut().enumerate().take(N) {
            match seq.next_element::<u128>()? {
                Some(value) => *item = unsafe { std::mem::transmute::<u128, __m128i>(value) },
                None => return Err(serde::de::Error::invalid_length(index, &self)),
            }
        }
        Ok(arr)
    }
}

pub fn deserialize_m128i_array<'de, D, const N: usize>(
    deserializer: D,
) -> Result<[__m128i; N], D::Error>
where
    D: serde::Deserializer<'de>,
{
    deserializer.deserialize_seq(M128iArrayVisitor::<N>)
}

pub fn serialize_m128i<S>(data: &__m128i, serializer: S) -> Result<S::Ok, S::Error>
where
    S: Serializer,
{
    let bytes: u128 = unsafe { std::mem::transmute(*data) };
    bytes.serialize(serializer)
}

pub fn deserialize_m128i<'de, D>(deserializer: D) -> Result<__m128i, D::Error>
where
    D: Deserializer<'de>,
{
    let bytes = u128::deserialize(deserializer)?;
    Ok(unsafe { std::mem::transmute::<u128, __m128i>(bytes) })
}

pub fn serialize_m128i_array<S>(value: &[__m128i], serializer: S) -> Result<S::Ok, S::Error>
where
    S: serde::Serializer,
{
    let mut seq = serializer.serialize_seq(Some(value.len()))?;
    for item in value {
        let bytes: u128 = unsafe { std::mem::transmute(*item) };
        seq.serialize_element(&bytes)?;
    }
    seq.end()
}

// -----------------------------
// Savestate I/O
// -----------------------------

pub fn create_savestate(device: &device::Device) {
    let mut rdp_state: Vec<u8> = vec![0; ui::video::state_size()];
    ui::video::save_state(rdp_state.as_mut_ptr());

    let data: &[(&[u8], &str)] = &[
        (&postcard::to_stdvec(device).unwrap(), "device"),
        (&postcard::to_stdvec(&device.ui.storage.saves).unwrap(), "saves"),
        (&rdp_state, "rdp_state"),
    ];
    let compressed_file = ui::storage::compress_file(data);
    std::fs::write(
        device.ui.storage.paths.savestate_file_path.clone(),
        compressed_file,
    )
    .unwrap();
    println!(
        "Savestate created at {}",
        device.ui.storage.paths.savestate_file_path.display()
    );
}

pub fn load_savestate(device: &mut device::Device) {
    // clone path to avoid borrow conflicts later
    let path = device.ui.storage.paths.savestate_file_path.clone();

    let savestate = std::fs::read(&path);
    if let Ok(savestate) = &savestate {
        let device_bytes = ui::storage::decompress_file(savestate, "device");
        let save_bytes   = ui::storage::decompress_file(savestate, "saves");
        let rdp_state    = ui::storage::decompress_file(savestate, "rdp_state");

        // --- keep runtime-only/process resources before we overwrite `device`
        let ui_keep       = std::mem::replace(&mut device.ui, ui::Ui::default());
        let netplay_keep  = device.netplay.take();
        let rom_keep      = device.cart.rom.clone();
        let mut tpak_rom_keep = [Vec::<u8>::new(), Vec::<u8>::new(), Vec::<u8>::new(), Vec::<u8>::new()];
        for i in 0..4 {
            tpak_rom_keep[i] = device.transferpaks[i].cart.rom.clone();
        }

        // decode small blob first (unchanged)
        let saves_new = match postcard::from_bytes(&save_bytes) {
            Ok(s)  => s,
            Err(e) => {
                eprintln!("Failed to decode savestate saves: {e:?}");
                // restore on failure
                device.ui = ui_keep;
                device.netplay = netplay_keep;
                return;
            }
        };

        // ✅ CRITICAL CHANGE:
        // Build the giant struct directly on the heap instead of on the stack.
        // We then swap heap<->heap with `device`, so no big local is created.
// --- where you currently do: postcard::from_bytes::<Box<device::Device>>(&device_bytes)
let mut loaded = match decode_device_with_grown_stack(&device_bytes) {
    Ok(b)  => b,
    Err(e) => {
        eprintln!("Failed to decode savestate device: {e:?}");
        // restore ui/netplay if you already stashed them
        device.ui = ui_keep;
        device.netplay = netplay_keep;
        return;
    }
};

// swap heap<->heap (as you have)
std::mem::swap(device, &mut *loaded);



        // restore runtime-only stuff we preserved
        device.ui       = ui_keep;
        device.netplay  = netplay_keep;
        device.cart.rom = rom_keep;
        for i in 0..4 {
            device.transferpaks[i].cart.rom = tpak_rom_keep[i].clone();
        }

        // apply saves
        device.ui.storage.saves = saves_new;

        // ---- rehydrate runtime tables / caches / function pointers (unchanged)

        device::memory::init(device);
        device::vi::set_expected_refresh_rate(device);
        device::cpu::map_instructions(device);
        device::cop0::map_instructions(device);
        device::cop1::map_instructions(device);
        device::cop2::map_instructions(device);
        device::rsp_cpu::map_instructions(device);

        let mut mem_addr = 0x1000;
        while mem_addr < 0x2000 {
            let data = u32::from_be_bytes(
                device.rsp.mem[mem_addr..mem_addr + 4].try_into().unwrap(),
            );
            let idx = (mem_addr & 0x0FFF) / 4;
            device.rsp.cpu.instructions[idx].func   = device::rsp_cpu::decode_opcode(device, data);
            device.rsp.cpu.instructions[idx].opcode = data;
            mem_addr += 4;
        }

        for line_index in 0..512 {
            for i in 0..8 {
                device.memory.icache[line_index].instruction[i] = device::cpu::decode_opcode(
                    device,
                    device.memory.icache[line_index].words[i],
                );
            }
        }

        device::pif::connect_pif_channels(device);
        for i in 0..4 {
            if let Some(handler) = device.pif.channels[i].pak_handler {
                use device::controller::{mempak, rumble, transferpak, PakHandler, PakType};
                let new_handler = match handler.pak_type {
                    PakType::RumblePak => PakHandler {
                        read: rumble::read,
                        write: rumble::write,
                        pak_type: PakType::RumblePak,
                    },
                    PakType::MemPak => PakHandler {
                        read: mempak::read,
                        write: mempak::write,
                        pak_type: PakType::MemPak,
                    },
                    PakType::TransferPak => PakHandler {
                        read: transferpak::read,
                        write: transferpak::write,
                        pak_type: PakType::TransferPak,
                    },
                    PakType::None => continue,
                };
                device.pif.channels[i].pak_handler = Some(new_handler);
            }
        }

        ui::audio::close_game_audio(&mut device.ui);
        ui::audio::init_game_audio(&mut device.ui, device.ai.freq);
        ui::video::load_state(device, rdp_state.as_ptr());

        println!("Savestate loaded from {}", path.display());
    }
}

// -----------------------------
// Defaults (unchanged)
// -----------------------------

pub fn default_pak_handler() -> fn(&mut device::Device, usize, u16, usize, usize) {
    device::controller::mempak::read
}

pub fn default_instruction() -> fn(&mut device::Device, u32) {
    device::cop0::reserved
}

pub fn default_instructions<const N: usize>() -> [fn(&mut device::Device, u32); N]
where
    [fn(&mut device::Device, u32); N]: Sized,
{
    [device::cop0::reserved; N]
}

pub fn default_memory_read_fast()
-> [fn(&device::Device, u64, device::memory::AccessSize) -> u32; 0x2000] {
    [device::unmapped::read_mem_fast; 0x2000]
}

pub fn default_memory_read()
-> [fn(&mut device::Device, u64, device::memory::AccessSize) -> u32; 0x2000] {
    [device::unmapped::read_mem; 0x2000]
}

pub fn default_memory_write() -> [fn(&mut device::Device, u64, u32, u32); 0x2000] {
    [device::unmapped::write_mem; 0x2000]
}
