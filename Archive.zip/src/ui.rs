pub mod audio;
pub mod cheats;
pub mod config;
pub mod gui;
pub mod input;
pub mod netplay;
pub mod storage;
pub mod video;
pub mod vru;

use std::ffi::CStr;
use std::path::PathBuf;


pub struct Dirs {
    pub config_dir: std::path::PathBuf,
    pub data_dir: std::path::PathBuf,
}

pub struct Audio {
    pub audio_device_spec: sdl3_sys::audio::SDL_AudioSpec,
    pub audio_stream: *mut sdl3_sys::audio::SDL_AudioStream,
    pub event_audio_stream: *mut sdl3_sys::audio::SDL_AudioStream,
    pub audio_device: u32,
    pub event_audio: audio::EventAudio,
    pub gain: f32,
}

pub struct Input {
    pub joysticks: Vec<sdl3_sys::joystick::SDL_JoystickID>,
    pub keyboard_state: *const bool,
    pub controllers: [input::Controllers; 4],
}

pub struct Storage {
    pub save_type: Vec<storage::SaveTypes>,
    pub paths: storage::Paths,
    pub saves: storage::Saves,
}

pub struct Video {
    pub window: *mut sdl3_sys::video::SDL_Window,
    pub fullscreen: bool,
}

pub struct Ui {
    pub dirs: Dirs,
    pub config: config::Config,
    pub game_id: String,
    pub game_hash: String,
    pub with_sdl: bool,
    pub audio: Audio,
    pub input: Input,
    pub storage: Storage,
    pub video: Video,
}

impl Drop for Ui {
    fn drop(&mut self) {
        if self.with_sdl {
            unsafe {
                sdl3_sys::init::SDL_Quit();
            }
        }
    }
}

unsafe extern "C" {
    /// Tell SDL we’ve already provided our own main(), so it won’t panic
    fn SDL_SetMainReady();
}

pub fn sdl_init(flag: sdl3_sys::init::SDL_InitFlags) {
    unsafe {
        // ── Add this line ────────────────────────────────────────
        SDL_SetMainReady();
        // ── End addition ────────────────────────────────────────

        let init = sdl3_sys::init::SDL_WasInit(0);
        if init & flag == 0 && !sdl3_sys::init::SDL_InitSubSystem(flag) {
            let err = CStr::from_ptr(sdl3_sys::error::SDL_GetError())
                .to_str()
                .unwrap();
            panic!("Could not initialize SDL subsystem: {flag}, {err}");
        }
    }
}

pub fn get_dirs() -> Dirs {
    let exe_path = std::env::current_exe().unwrap();
    let portable_dir = exe_path.parent();
    let portable = portable_dir.unwrap().join("portable.txt").exists();
    let config_dir;
    let data_dir;
    if portable {
        config_dir = portable_dir.unwrap().join("portable_data").join("config");
        data_dir = portable_dir.unwrap().join("portable_data").join("data");
    } else {
        config_dir = dirs::config_dir().unwrap().join("n64Plus");
        data_dir = dirs::data_dir().unwrap().join("n64Plus");
    };

    Dirs {
        config_dir,
        data_dir,
    }
}

impl Ui {
    fn construct_ui(joysticks: Vec<u32>, with_sdl: bool) -> Ui {
        let dirs = get_dirs();

        Ui {
            input: Input {
                controllers: [
                    input::Controllers {
                        game_controller: std::ptr::null_mut(),
                        joystick: std::ptr::null_mut(),
                        rumble: false,
                    },
                    input::Controllers {
                        game_controller: std::ptr::null_mut(),
                        joystick: std::ptr::null_mut(),
                        rumble: false,
                    },
                    input::Controllers {
                        game_controller: std::ptr::null_mut(),
                        joystick: std::ptr::null_mut(),
                        rumble: false,
                    },
                    input::Controllers {
                        game_controller: std::ptr::null_mut(),
                        joystick: std::ptr::null_mut(),
                        rumble: false,
                    },
                ],
                keyboard_state: std::ptr::null_mut(),
                joysticks,
            },
            storage: Storage {
                save_type: vec![],
                paths: storage::Paths {
                    eep_file_path: std::path::PathBuf::new(),
                    fla_file_path: std::path::PathBuf::new(),
                    sra_file_path: std::path::PathBuf::new(),
                    pak_file_path: std::path::PathBuf::new(),
                    sdcard_file_path: std::path::PathBuf::new(),
                    romsave_file_path: std::path::PathBuf::new(),
                    savestate_file_path: std::path::PathBuf::new(),
                },
                saves: storage::Saves {
                    write_to_disk: true,
                    eeprom: storage::Save {
                        data: Vec::new(),
                        written: false,
                    },
                    sram: storage::Save {
                        data: Vec::new(),
                        written: false,
                    },
                    flash: storage::Save {
                        data: Vec::new(),
                        written: false,
                    },
                    mempak: storage::Save {
                        data: Vec::new(),
                        written: false,
                    },
                    sdcard: storage::Save {
                        data: Vec::new(),
                        written: false,
                    },
                    romsave: storage::RomSave {
                        data: std::collections::HashMap::new(),
                        written: false,
                    },
                },
            },
            config: config::Config::new(),
            game_id: String::new(),
            game_hash: String::new(),
audio: Audio {
    event_audio: audio::EventAudio {
        mempak: Vec::new(),
        rumblepak: Vec::new(),
        transferpak: Vec::new(),
        netplay_desync: Vec::new(),
        netplay_lost_connection: Vec::new(),
        netplay_disconnected: [Vec::new(), Vec::new(), Vec::new(), Vec::new()],
        cheats_enabled: Vec::new(),
    },
    audio_device_spec: Default::default(),
    audio_stream: std::ptr::null_mut(),
    event_audio_stream: std::ptr::null_mut(),
    audio_device: 0,
    gain: 1.0,
},


            video: Video {
                window: std::ptr::null_mut(),
                fullscreen: false,
            },
            dirs,
            with_sdl,
        }
    }

    pub fn default() -> Ui {
        Self::construct_ui(vec![], false)
    }

    pub fn new() -> Ui {
        sdl_init(sdl3_sys::init::SDL_INIT_GAMEPAD);
        let mut num_joysticks = 0;
        let joysticks = unsafe { sdl3_sys::joystick::SDL_GetJoysticks(&mut num_joysticks) };
        if joysticks.is_null() {
            panic!("Could not get joystick list");
        }
        let mut joystick_vec = vec![];
        for i in 0..num_joysticks {
            joystick_vec.push(unsafe { *joysticks.add(i as usize) });
        }
        unsafe { sdl3_sys::stdinc::SDL_free(joysticks as *mut std::ffi::c_void) }
        Self::construct_ui(joystick_vec, true)
    }
}
