#ifndef FB_FORMATS_H_
#define FB_FORMATS_H_

const int FB_FMT_I4 = 0;
const int FB_FMT_I8 = 1;
const int FB_FMT_RGBA5551 = 2;
const int FB_FMT_IA88 = 3;
const int FB_FMT_RGBA8888 = 4;

#endif