#include <chrono>
#include <cstdlib> // getenv, strtol
#include "command_ring.hpp"
#include "rdp_device.hpp"
#include "thread_id.hpp"
#include <assert.h>

namespace RDP
{
void CommandRing::init(
#ifdef PARALLEL_RDP_SHADER_DIR
		Granite::Global::GlobalManagersHandle global_handles_,
#endif
		CommandProcessor *processor_, unsigned count)
{
	assert((count & (count - 1)) == 0);
	teardown_thread();
	processor = processor_;
	ring.resize(count);
	write_count = 0;
	read_count = 0;
#ifdef PARALLEL_RDP_SHADER_DIR
	global_handles = std::move(global_handles_);
#endif
	thr = std::thread(&CommandRing::thread_loop, this);
}

void CommandRing::teardown_thread()
{
	if (thr.joinable())
	{
		enqueue_command(0, nullptr);
		thr.join();
	}
}

CommandRing::~CommandRing()
{
	teardown_thread();
}

void CommandRing::drain()
{
	std::unique_lock<std::mutex> holder{lock};
	cond.wait(holder, [this]() {
		return write_count == completed_count;
	});
}

void CommandRing::enqueue_command(unsigned num_words, const uint32_t *words)
{
	std::unique_lock<std::mutex> holder{lock};
	cond.wait(holder, [this, num_words]() {
		return write_count + num_words + 1 <= read_count + ring.size();
	});

	size_t mask = ring.size() - 1;
	ring[write_count++ & mask] = num_words;
	for (unsigned i = 0; i < num_words; i++)
		ring[write_count++ & mask] = words[i];

	cond.notify_one();
}

static inline long get_env_long(const char* key, long fallback)
{
	if (const char* v = std::getenv(key))
	{
		char* end = nullptr;
		long parsed = std::strtol(v, &end, 10);
		if (end && end != v)
			return parsed;
	}
	return fallback;
}

void CommandRing::thread_loop()
{
    Util::register_thread_index(0);

#ifdef PARALLEL_RDP_SHADER_DIR
    Granite::Global::set_thread_context(*global_handles);
    global_handles.reset();
#endif

    const size_t mask = ring.size() - 1;
    using clock = std::chrono::steady_clock;
    auto last_idle_emit = clock::now();

#if defined(__APPLE__)
    auto idle_emit_interval = std::chrono::microseconds(6000); // 6 ms
    auto wait_slice         = std::chrono::microseconds(1500);
    bool disable_metaidle   = true;
    if (const char* v = std::getenv("N64_RDP_DISABLE_METAIDLE"))
        disable_metaidle = (*v != '0');
    long batch_us_default   = 1000; // up to 1.0 ms of draining
#else
    auto idle_emit_interval = std::chrono::microseconds(1500);
    auto wait_slice         = std::chrono::microseconds(500);
    bool disable_metaidle   = false;
    if (const char* v = std::getenv("N64_RDP_DISABLE_METAIDLE"))
        disable_metaidle = (*v != '0');
    long batch_us_default   = 500;  // up to 0.5 ms of draining
#endif

    auto get_env_long = [](const char* key, long fallback) -> long {
        if (const char* v = std::getenv(key)) {
            char* end = nullptr;
            long parsed = std::strtol(v, &end, 10);
            if (end && end != v) return parsed;
        }
        return fallback;
    };

    const long batch_us_cfg    = get_env_long("N64_RDP_BATCH_US", batch_us_default);
    const long batch_pkts_cfg  = get_env_long("N64_RDP_BATCH_PKTS", 64);
    const auto drain_budget    = std::chrono::microseconds(batch_us_cfg > 0 ? batch_us_cfg : 0);
    const size_t max_pkts      = batch_pkts_cfg > 0 ? size_t(batch_pkts_cfg) : size_t(64);
    const bool drain_enabled   = (batch_us_cfg > 0) && (max_pkts > 0);

    std::vector<uint32_t> payload;
    payload.reserve(256);

    for (;;)
    {
        bool emit_idle = false;
        bool saw_shutdown = false;
        size_t packets_processed = 0;
        auto drain_deadline = clock::now() + drain_budget;

        {
            std::unique_lock<std::mutex> holder{lock};

            // Wait for at least one packet, or time out for MetaIdle.
            if (!cond.wait_for(holder, wait_slice, [this]() { return write_count > read_count; }))
            {
                const auto now = clock::now();
                const bool ring_empty = (write_count == read_count);
                if (!disable_metaidle && ring_empty && (now - last_idle_emit) >= idle_emit_interval)
                {
                    last_idle_emit = now;
                    emit_idle = true;
                }
            }
            else
            {
                // Drain loop: read as many packets as budget allows, but
                // always pass them to the processor one-by-one.
                do {
                    if (write_count == read_count)
                        break;

                    uint32_t num_words = ring[read_count++ & mask];

                    // Sentinel = clean shutdown. Only exit after we’ve processed
                    // any packets already pulled in this wake cycle.
                    if (num_words == 0) {
                        saw_shutdown = true;
                        break;
                    }

                    payload.resize(num_words);
                    for (uint32_t i = 0; i < num_words; i++)
                        payload[i] = ring[read_count++ & mask];

                    // Drop lock while processing to minimize contention.
                    holder.unlock();
                    processor->enqueue_command_direct(uint32_t(payload.size()), payload.data());
                    holder.lock();

                    packets_processed++;
                } while (drain_enabled &&
                         packets_processed < max_pkts &&
                         clock::now() < drain_deadline);
            }
        }

        // Emit MetaIdle outside the lock.
        if (emit_idle)
        {
            const uint32_t idle = uint32_t(Op::MetaIdle) << 24;
            processor->enqueue_command_direct(1, &idle);
            continue; // no completion advancement for idle
        }

        // If we processed any real packets, advance completion once per batch.
        if (packets_processed > 0)
        {
            std::lock_guard<std::mutex> holder{lock};
            completed_count = read_count;
            cond.notify_one();
        }

        if (saw_shutdown)
            break;
    }
}
}