#pragma once

#include "wsi.hpp"
#include <SDL3/SDL.h>

class SDL_WSIPlatform : public Vulkan::WSIPlatform
{
public:
    VkSurfaceKHR create_surface(VkInstance instance, VkPhysicalDevice gpu) override;
    void destroy_surface(VkInstance instance, VkSurfaceKHR surface) override;
    std::vector<const char *> get_instance_extensions() override;
    uint32_t get_surface_width() override;
    uint32_t get_surface_height() override;
    bool alive(Vulkan::WSI &wsi) override;
    void poll_input() override;
    void poll_input_async(Granite::InputTrackerHandler *) override;
    void set_window(SDL_Window *_window);
    void do_resize();

    // 👇 add these tiny accessors so we can read the last known swapchain size
    uint32_t current_width()  const { return current_swapchain_width; }
    uint32_t current_height() const { return current_swapchain_height; }

private:
    SDL_Window *window;
};

