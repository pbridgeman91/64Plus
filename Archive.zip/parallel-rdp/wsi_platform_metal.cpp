// // --- wsi_platform.cpp
// #define VK_USE_PLATFORM_METAL_EXT 1

// #include "wsi_platform.hpp"
// #include <SDL3/SDL_vulkan.h>
// #include <SDL3/SDL_error.h>
// #include "vulkan_headers.hpp"        // your project wrapper; brings in vulkan_core.h
// #include <vulkan/vulkan_metal.h>     // <-- for VkMetalSurfaceCreateInfoEXT, PFN_vkCreateMetalSurfaceEXT

// // Rust export that returns CAMetalLayer* we created via SDL_Metal_CreateView().
// extern "C" void *sdl_get_metal_layer();

// VkSurfaceKHR SDL_WSIPlatform::create_surface(VkInstance instance, VkPhysicalDevice)
// {
//     VkSurfaceKHR surface = VK_NULL_HANDLE;

// #if !defined(__APPLE__)
//     if (SDL_Vulkan_CreateSurface(window, instance, nullptr, &surface) && surface != VK_NULL_HANDLE)
//         return surface;
//     const char *sdl_err = SDL_GetError();
//     if (sdl_err && *sdl_err) printf("SDL_Vulkan_CreateSurface failed: %s\n", sdl_err);
// #else
//     // On Apple we render into a CAMetalLayer, so skip SDL_Vulkan_CreateSurface entirely
// #endif

//     // Metal surface fallback (Apple)
//     void *layer = sdl_get_metal_layer();
//     if (!layer) {
//         printf("Fallback surface creation aborted: no CAMetalLayer available.\n");
//         return VK_NULL_HANDLE;
//     }

//     auto pfnCreateMetalSurfaceEXT =
//         reinterpret_cast<PFN_vkCreateMetalSurfaceEXT>(
//             vkGetInstanceProcAddr(instance, "vkCreateMetalSurfaceEXT"));
//     if (!pfnCreateMetalSurfaceEXT) {
//         printf("vkCreateMetalSurfaceEXT not found (VK_EXT_metal_surface not enabled?).\n");
//         return VK_NULL_HANDLE;
//     }

//     VkMetalSurfaceCreateInfoEXT ci{ };
//     ci.sType  = VK_STRUCTURE_TYPE_METAL_SURFACE_CREATE_INFO_EXT;
//     ci.pLayer = layer; // CAMetalLayer*

//     if (pfnCreateMetalSurfaceEXT(instance, &ci, nullptr, &surface) != VK_SUCCESS || surface == VK_NULL_HANDLE) {
//         printf("vkCreateMetalSurfaceEXT failed.\n");
//         return VK_NULL_HANDLE;
//     }
//     return surface;
// }


// void SDL_WSIPlatform::destroy_surface(VkInstance instance, VkSurfaceKHR surface)
// {
//     // Works for both creation paths (SDL just wraps vkDestroySurfaceKHR).
//     SDL_Vulkan_DestroySurface(instance, surface, nullptr);
// }


// std::vector<const char *> SDL_WSIPlatform::get_instance_extensions()
// {
//     unsigned int count = 0;
//     const char *const *ext = SDL_Vulkan_GetInstanceExtensions(&count);
//     if (!ext)
//         printf("Error getting instance extensions\n");

//     std::vector<const char *> names;
//     names.reserve(count);
//     for (unsigned int i = 0; i < count; ++i)
//         names.push_back(ext[i]);
//     return names;
// }

// // In wsi_platform.cpp

// // You already have this forward declaration from your FFI
// extern "C" bool sdl_get_metal_drawable_size(uint32_t *out_w, uint32_t *out_h);

// uint32_t SDL_WSIPlatform::get_surface_width()
// {
//     uint32_t w = 0, h = 0;
//     // Prioritize the actual drawable size from the Metal layer.
//     if (sdl_get_metal_drawable_size(&w, &h) && w > 0) {
//         return w;
//     }
//     // Fallback for when the layer might not be available yet.
//     SDL_GetWindowSizeInPixels(window, (int*)&w, (int*)&h);
//     return w;
// }

// uint32_t SDL_WSIPlatform::get_surface_height()
// {
//     uint32_t w = 0, h = 0;
//     // Prioritize the actual drawable size from the Metal layer.
//     if (sdl_get_metal_drawable_size(&w, &h) && h > 0) {
//         return h;
//     }
//     // Fallback
//     SDL_GetWindowSizeInPixels(window, (int*)&w, (int*)&h);
//     return h;
// }

// bool SDL_WSIPlatform::alive(Vulkan::WSI &)
// {
//     return true;
// }

// void SDL_WSIPlatform::poll_input() {}
// void SDL_WSIPlatform::poll_input_async(Granite::InputTrackerHandler *) {}
// void SDL_WSIPlatform::set_window(SDL_Window *_window) { window = _window; }
// void SDL_WSIPlatform::do_resize() { resize = true; }
