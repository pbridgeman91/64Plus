use std::path::Path;

fn main() {
    println!("cargo:rerun-if-changed=build.rs");

    if cfg!(feature = "framework") {
        // compute "<repo-root>/ios-libs"
        let manifest = Path::new(env!("CARGO_MANIFEST_DIR"));
        let repo_root = manifest.parent().unwrap().parent().unwrap();
        let framework_path = repo_root.join("ios-libs");

        println!("cargo:rustc-link-search=framework={}", framework_path.display());
        println!("cargo:rustc-link-lib=framework=SDL3");
        // any other system frameworks SDL needs
        println!("cargo:rustc-link-lib=framework=UIKit");
        println!("cargo:rustc-link-lib=framework=Foundation");
        println!("cargo:rustc-link-lib=framework=CoreGraphics");
    } else {
        // fallback to pkg-config on non-iOS (or when you want to use pkg-config)
        pkg_config::Config::new()
            .statik(false)
            .probe("SDL3")
            .expect("Could not find SDL3 via pkg-config");
    }
}
